#define _XTAL_FREQ 1000000

#include <xc.h>
#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) 
{
    unsigned char a, b, op, res;

    TRISD = 0x00;
    res = 0;

    while (1) {

     PORTD = res;
     res++;

    }
 
    return (EXIT_SUCCESS);
}

