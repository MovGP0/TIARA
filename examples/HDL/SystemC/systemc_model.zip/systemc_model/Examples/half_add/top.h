#ifndef topH
#define topH

#include "half_add.h"

SC_MODULE(top)
{
  sc_signal<sc_logic> A,B,S,C;
  
  half_add U1;

  SC_CTOR(top): U1("U1")
  {
    U1.A(A); U1.B(B); U1.S(S); U1.C(C); 
  }
};
#endif

