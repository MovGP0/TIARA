#ifndef SC_EXTERNS_H
#define SC_EXTERNS_H

int main( int argc, char* argv[] );

#endif
