//---------------------------------------------------------------------------

#ifndef string_utilH
#define string_utilH

void StrUpperCase(char src[], char dest[]);
void StrDelete(char* s, int offset, int count);
char* StrSubString(char* src, char* dest, int index, int count);
int StrPos(char* substr, char* str);
int StrWPos(const wchar_t* substr, wchar_t* str);
unsigned int hexToInt(char *hex);
char* decimal_to_binary(char* pointer, int n, int len);
int ToInt(wchar_t* a, int i);
void IntToHex(int decimalNumber, char* hexadecimalNumber);

#endif
