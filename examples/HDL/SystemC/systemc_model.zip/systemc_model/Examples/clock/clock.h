#ifndef clockH
#define clockH

#include "systemc.h"
#include "C_SCPLI.h"
#include "monitor.h"

SC_MODULE(clock)
{
  sc_out<sc_logic> CLK;
  
  monitor MON;

  void proc() 
  {
   int a = 1000;
   while(true) {
	CLK.write(SC_LOGIC_0);

	#ifdef DEBUG
	debug.open(debug_file_name, std::ofstream::out | std::ofstream::app);
	debug << "clock::proc: 1: " << sc_get_curr_simcontext()->time_stamp().to_string() << endl;
	debug.close();
	#endif

	wait(a, SC_NS);
	CLK.write(SC_LOGIC_1);

	#ifdef DEBUG
	debug.open(debug_file_name, std::ofstream::out | std::ofstream::app);
	debug << "clock::proc: 2: " << sc_get_curr_simcontext()->time_stamp().to_string() << endl;
	debug.close();
	#endif

	wait(a, SC_NS);
   }
  }

  SC_CTOR(clock): MON("MON")
  {
    SC_THREAD(proc);
    MON << CLK;
  }
};
#endif

