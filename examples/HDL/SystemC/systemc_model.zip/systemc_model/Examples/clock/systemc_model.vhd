-- This is the interface part of the SystemC model 
-- The SystemC project compiled externally by Visual Studio 2015
-- The compiled DLL file and the interface file (VHDL) assigned by Tools/New Macro Wizard..
-- See the documentation for details

library ieee;
use ieee.std_logic_1164.all;

ENTITY clock is port(	
 CLK: out std_logic
);
END clock;

ARCHITECTURE behv of clock is		 	  
BEGIN
END behv;
