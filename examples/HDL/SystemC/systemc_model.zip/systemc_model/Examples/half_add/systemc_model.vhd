-- This is the interface part of the SystemC model 
-- The SystemC project compiled externally by Visual Studio 2015
-- The compiled DLL file and the interface file (VHDL) assigned by Tools/New Macro Wizard..
-- See the documentation for details

library ieee;
use ieee.std_logic_1164.all;

ENTITY e_Half_add_entity IS PORT(
  A : IN std_logic; 
  B : IN std_logic;
  S : OUT std_logic; 
  C : OUT std_logic 
 );
END e_Half_add_entity;

ARCHITECTURE a_Half_add_arch of e_Half_add_entity IS
BEGIN
END a_Half_add_arch;
