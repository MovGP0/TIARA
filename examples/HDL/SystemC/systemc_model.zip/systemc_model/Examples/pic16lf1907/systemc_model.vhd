------------------------------------
-- TINA HDL Macro Description Begin
-- 
-- entity_name:PIC16LF1907;
-- arch_name:ignored;
-- ports: MCLR, RA0, RA1, RA2, RA3, RA4, RA5, VSS, RA7, RA6, RC0, RC1, RC2, RC3, RE0, RE1, RE2, RE3, RD7
--        ;
--        RB7, RB6, RB5, RB4, RB3, RB2, RB1, RB0, VDD, RC7, RC6, RC5, RC4, RD0, RD1, RD2, RD3, RD4, RD5, RD6
--        ;
-- Mode:SystemCTyp;
-- 
-- TINA HDL Macro Description End
------------------------------------

-- This is the interface part of the SystemC model 
-- The SystemC project compiled externally by Visual Studio 2015
-- The compiled DLL file and the interface file (VHDL) assigned by Tools/New Macro Wizard..
-- See the documentation for details
-- 40 PIN PDIP

library ieee;
use ieee.std_logic_1164.all;

ENTITY PIC16LF1907 is port(	
 MCLR, RA0, RA1, RA2, RA3, RA4, RA5, VSS, RA7, RA6, RC0, RC1, RC2, RC3:	inout std_logic;
 RB7, RB6, RB5, RB4, RB3, RB2, RB1, RB0, VDD, RC7, RC6, RC5, RC4: inout std_logic;
 RD0, RD1, RD2, RD3, RD4, RD5, RD6, RD7: inout std_logic;
 RE0, RE1, RE2, RE3: inout std_logic
); 
END PIC16LF1907;

ARCHITECTURE behv of PIC16LF1907 is		 	  
BEGIN
END behv;
