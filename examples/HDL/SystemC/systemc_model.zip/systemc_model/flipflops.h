#ifndef jkffpcH
#define jkffpcH

#include "systemc.h"

template <int latching = 0, int tpLH = 0, int tpHL = 0>
SC_MODULE(jkffpc)
{
 sc_in<sc_logic> j, k, clk, cl, pr; 
 sc_out<sc_logic> q, qNot; 
 sc_logic q_s, var_a;

 void proc() 
 { 
  while (true)
  {
   wait();
   double t = sc_get_curr_simcontext()->time_stamp().to_seconds();
   if (cl == SC_LOGIC_0)
    q_s = SC_LOGIC_0;
   else if (pr == SC_LOGIC_0)
    q_s = SC_LOGIC_1;
   else if (t > 0 && clk.event() && (clk == SC_LOGIC_1 && latching == 0 || clk == SC_LOGIC_0 && latching == 1)) {
    if (j == SC_LOGIC_1 && k == SC_LOGIC_1)
     q_s  = ~q_s;
    else if (k == SC_LOGIC_1)
     q_s = SC_LOGIC_0;
    else if (j == SC_LOGIC_1)
     q_s = SC_LOGIC_1;
   }
	
   var_a = q_s;
   if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
   q = q_s;
   qNot = ~q_s;
  }
 }
  
 SC_CTOR(jkffpc)    
 {
  q_s = SC_LOGIC_0;
  SC_THREAD(proc);
  sensitive << cl << clk.value_changed() << pr;
 }
};

template <int latching = 0, int tpLH = 0, int tpHL = 0>
SC_MODULE(jkffpc_ms)
{
 sc_in<sc_logic> j, k, clk, c, p; 
 sc_out<sc_logic> q, qNot; 
 sc_signal<sc_logic> N2, N9, N10;

 jkffpc<latching,tpLH,tpHL> U1;
 jkffpc<latching,tpLH,tpHL> U2;
 
 void proc() 
 { 
  N2.write(~clk.read());
 }
 
 SC_CTOR(jkffpc_ms): U1("U1"), U2("U2")
 {
  U1.j(j);  U1.k(k);   U1.clk(clk); U1.cl(c); U1.pr(p); U1.q(N9); U1.qNot(N10);
  U2.j(N9); U2.k(N10); U2.clk(N2); U2.cl(c); U2.pr(p); U2.q(q); U2.qNot(qNot);
  SC_METHOD(proc);
  sensitive << c << clk.value_changed() << p;
 }
};

#endif

