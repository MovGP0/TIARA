#ifndef monitorH
#define monitorH

#include "systemc.h"
#include "C_SCPLI.h"

SC_MODULE(monitor)
{
  sc_in<sc_logic> D0, D1, D2, D3, D4;

  SC_CTOR(monitor)
  {
    SC_METHOD(proc);
    sensitive << D0 << D1 << D2 << D3 << D4;
  }

  void proc()
  {
    sc_pli_set_node_changed(true);
    sc_pause();
  }
};
#endif

