#include "stdafx.h"
#include <ctype.h>
#include <string.h>
#include "string_util.h"


void StrUpperCase(char src[], char dest[])
{
 int i = 0;

 while (src[i])
 {
     dest[i] = toupper(src[i]);
     i++;
 }
 dest[i] = '\0';
}

void StrDelete(char* s, int offset, int count)
{
 offset--;
 int len = strlen(s);
 if (offset < 0 || offset > len)
  return;

 if ( (offset+count) > len )
  count = len - offset;
 strcpy(s+offset, s+offset+count);
}

char* StrSubString(char* src, char* dest, int index, int count)
{
 int i, l = strlen(src);
 index--;

 if (index < 0 || index > l) {
  dest[0] = '\0';
  return dest;
 }

 for (i=0; i<count; i++)
  dest[i] = src[index+i];
 dest[i] = '\0';

 return dest;
}

int StrPos(char* substr, char* str) 
{
   char* res = strstr(str, substr); 
   if (res == NULL) return 0;
   else             return res - str + 1;
}

int StrWPos(const wchar_t* substr, wchar_t* str) 
{
   wchar_t* res = wcsstr(str, substr); 
   if (res == NULL) return 0;
   else             return res - str + 1;
}

int ToInt(wchar_t* a, int i)
{
	int result = 0;
	
	while (a[i] && a[i] >= '0' && a[i] <= '9') {
  	  result += (a[i] - '0');
		
      if (a[++i])
        result *= 10;
	}

	return result;
}

unsigned int hexToInt(char *hex)
{
  unsigned int result = 0;

  while (*hex)
    {
      if (*hex > 47 && *hex < 58)
        result += (*hex - 48);
      else if (*hex > 64 && *hex < 71)
        result += (*hex - 55);
      else if (*hex > 96 && *hex < 103)
        result += (*hex - 87);

      if (*++hex)
        result <<= 4;
    }

  return result;
}

char* decimal_to_binary(char* pointer, int n, int len)
{
   int c, d, count;

   count = 0;

   for ( c = len-1 ; c >= 0 ; c-- )
   {
      d = n >> c;

      if ( d & 1 )
         *(pointer+count) = 1 + '0';
      else
         *(pointer+count) = 0 + '0';

      count++;
   }
   *(pointer+count) = '\0';

   return  pointer;
}

void IntToHex(int decimalNumber, char* hexadecimalNumber)
{
	int remainder, quotient;
	int i=0, j=0, temp;
	char num_temp[256];
	
    quotient = decimalNumber;

    while(quotient!=0){
         temp = quotient % 16;

      //To convert integer into character
      if ( temp < 10)
           temp =temp + 48;
      else
         temp = temp + 55;

	  num_temp[i++]= temp;
      quotient = quotient / 16;
    }

	i--;
	while (i >= 0) {
		hexadecimalNumber[j++] = num_temp[i--];
	}
	hexadecimalNumber[j] = '\0';

}

