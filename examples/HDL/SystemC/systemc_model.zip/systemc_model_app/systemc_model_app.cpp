// systemc_model_app.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "C_SCPLI.h"


enum sc_time_unit
{
    SC_FS = 0,
    SC_PS,
    SC_NS,
    SC_US,
    SC_MS,
    SC_SEC
};

int main(int argc, char* argv[])
{
	int a;
	char* session_handle;
	double t;

	a = sc_pli_newdesign(argc, argv);
    sc_pli_run(100, SC_US);

	return a;
}



