#define _XTAL_FREQ 1000000

#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
 
/*
 * 
 */
int main(int argc, char** argv) 
{
    unsigned char a, b, op, res;

    TRISA = 0xFF;
    TRISB = 0xFF;
    TRISC = 0x00;

    while (1) {

     a = PORTB & 0x0F;
     b = (PORTB & 0xF0) >> 4;
     op = PORTA & 0x0F;

     if (op == 1)
      res = a+b;
     else if (op == 2)
      res = a-b;
     else if (op == 3)
      res = a/b;
     else
      res = a*b;

     PORTC = res;

    }
 
    return (EXIT_SUCCESS);
}
