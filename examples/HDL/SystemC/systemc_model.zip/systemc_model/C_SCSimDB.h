#ifndef C_SCSimDBH
#define C_SCSimDBH

#define n_default_entries 100

class TSimDB {
private:
 char* entries;
 int n_entries, n_entries_alloc, n_signals, entry_size;
 double last_time;
 bool first_run;

 void update_header();

public:

 TSimDB();
 ~TSimDB();

 void add_simdb_new_entry(double t);
 void add_entry(double t, char v, int idx);
 void alloc(int a);
 char* get_ptr(int& a, int& b) { a = n_entries; b = n_signals; return entries; }
};

#endif
