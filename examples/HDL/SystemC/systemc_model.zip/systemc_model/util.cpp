#include "stdafx.h"
#include "util.h"
 
std::ofstream debug;
