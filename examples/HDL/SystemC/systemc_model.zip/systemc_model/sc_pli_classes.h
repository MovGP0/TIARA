#ifndef sc_pli_classesH
#define sc_pli_classesH

#include "stdafx.h"
#include "systemc.h"

#define PORT_IN_TYP 1
#define PORT_OUT_TYP 2

#define SC_MIXED_MODE 0
#define SC_DIGITAL_MODE 1

#define UNKNOWN_TYPE_ID_VIRTUAL           0
#define INTEGER_TYPE_ID_VIRTUAL           1
#define BIT_TYPE_ID_VIRTUAL               2
#define STD_LOGIC_TYPE_ID_VIRTUAL         3
#define STD_LOGIC_VECTOR_TYPE_ID_VIRTUAL  4
#define FLOAT_TYPE_ID_VIRTUAL             5
#define BOOLEAN_TYPE_ID_VIRTUAL           6
#define TYPE_MAX                          6

// sc pli internal
#define BOOL_TO_STD_LOGIC_TYPE_ID_VIRTUAL 7

#define TYPE_CAST_NO        0
#define TYPE_CAST_SC_SIGNAL 1
#define TYPE_CAST_SC_IN     2
#define TYPE_CAST_SC_OUT    3 
#define TYPE_CAST_SC_INOUT  4 

class pli_interface_class {
public:
 void* p_object;
 int type_id, dig_node, pin_no, type_cast;
 char* name;
 
 pli_interface_class() { p_object = NULL; type_id = dig_node = pin_no = type_cast = 0; name = NULL; }
};

class pli_mixed_node {
public:
 char* name;
 int type_id, dig_node;
};

class pli_dig_node_to_signal {
public:
 pli_interface_class* i_node;
 
 pli_dig_node_to_signal() { i_node = NULL; }
};

#endif
