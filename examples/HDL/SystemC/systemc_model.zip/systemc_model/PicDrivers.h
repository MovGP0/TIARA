//---------------------------------------------------------------------------

#ifndef PicDriversH
#define PicDriversH

#define PIC_DEVICE_MAXIMUM_PORT_COUNT   5
#define PIC_DEVICE_MAXIMUM_PIN_COUNT    100
#define PIC_DEVICE_MEMORY_SIZE          512
#define PIC_DEVICE_EEPROM_SIZE          256

class PicDriverBase
{
protected:
      int iRefNo;
      McuPeripheralUser *parent;

      int          *iLogType;
      int          *iLogLevel;

public:
      void SetParent(McuPeripheralUser *user,int *log_type,int *log_level)
      {
           parent = user;
           iLogType = log_type;
           iLogLevel = log_level;
      }
};

class PicDriver : public PicDriverBase
{
};

class PicPortDriver : public PicDriver
{
private:
      int  iPortCount;
      int  iPortStartAddress;
      int  iTrisStartAddress;

      char cPinToPort[ PIC_DEVICE_MAXIMUM_PIN_COUNT ];
      char cPinToBit [ PIC_DEVICE_MAXIMUM_PIN_COUNT ];

      char cPortToPin[ PIC_DEVICE_MAXIMUM_PORT_COUNT * 8 ];
      BYTE cPortMask[PIC_DEVICE_MAXIMUM_PORT_COUNT];
      BYTE cPortLatch[PIC_DEVICE_MAXIMUM_PORT_COUNT];

public:

      PicPortDriver()
      {
           iPortCount = 0;
           iPortStartAddress = 0x05;
           iTrisStartAddress = 0x85;
      }
	  
      void Create(long port_start_address,long tris_start_address,long port_count,int *port_to_pin)
      {
           iPortStartAddress = port_start_address;
           iTrisStartAddress = tris_start_address;

           iPortCount = port_count;

           for ( int i = 0; i < iPortCount * 8 ; i++ )
           {
                 cPinToPort[i] = -1;
                 cPinToBit[i]  = -1;
           }

           for ( int i = 0; i < iPortCount; i++ )
           {
                 cPortMask[i] = 0;
                 for ( int j = 0; j < 8; j++ )
                 {
                       cPortToPin [ i * 8 + j ] = port_to_pin [ i * 8 + j ];
                       if ( port_to_pin [ i * 8 + j ] < 0 )continue;

                       cPortMask[i] |= ( 1 << j );
                       cPinToPort [ port_to_pin [ i * 8 + j ] ] = i;
                       cPinToBit  [ port_to_pin [ i * 8 + j ] ] = j;
                 }
           }
      }
	  
      void Reset(int type)
      {
           if ( type != RESET_POWER_ON )return;

           for ( int i = 0; i < iPortCount; i++ )
           {
                 parent->P_WriteMemory ( iPortStartAddress + i , cPortMask[i] );
                 parent->P_WriteMemory ( iTrisStartAddress + i , cPortMask[i] );
                 cPortLatch[i] = /*cPortMask[i]*/ 0;                                // Attila PINDEFAULTZERO: 2009/07/26

                 for ( int j = 0; j < 8; j++ )
                 {
                      if ( cPortToPin [ i * 8 + j ] < 0 )continue;

                      parent->P_SetPinStatus ( cPortToPin [ i * 8 + j ], 1 );
                      parent->P_SetPinData ( cPortToPin [ i * 8 + j ] , /*1*/ 0 );  // Attila PINDEFAULTZERO: 2009/07/26
                 }
           }
      }
	  
      bool MemoryChanged(int port_addr,BYTE c_current) // by code
      {
           int port_no = 0;
           if ( port_addr >= iPortStartAddress && port_addr < iPortStartAddress + iPortCount )
           {
                port_no = port_addr - iPortStartAddress;
                c_current = ( c_current & cPortMask[port_no]);
                cPortLatch[port_addr - iPortStartAddress] = c_current;
           }
           else if ( port_addr >= iTrisStartAddress && port_addr < iTrisStartAddress + iPortCount )
           {
                port_no = port_addr - iTrisStartAddress;
                c_current = ( c_current & cPortMask[port_no]);

                parent->P_WriteMemory(port_addr,c_current);
           }
           else return false;

           BYTE c_latch = cPortLatch[port_no];
           BYTE c_tris = parent->P_ReadMemory(iTrisStartAddress + port_no);
           BYTE c_bus = 0;
           BYTE c_pin = 0;

           for ( int i = 0; i < 8; i++ )if ( parent->P_GetPinData(cPortToPin[port_no*8+i] ) )c_pin |= ( 1 << i );
           for ( int i = 0; i < 8; i++ )
           {
                parent->P_SetPinStatus( cPortToPin [ port_no * 8 + i ], ( c_tris & ( 1 << i ) ) );
                if ( c_tris & ( 1 << i ) )c_bus |= ( c_pin & ( 1 << i ) );  //input mode
                else //output mode
                {
                     bool b_out = ( c_latch & ( 1 << i ) );
                     if ( b_out )c_bus |= ( 1 << i ); //output mode
                     parent->P_SetPinData(cPortToPin [ port_no * 8 + i ], b_out);
                }
           }
           // Anyway AD events will be lost
           // parent->P_WriteMemory(iPortStartAddress + port_no, c_bus);

           return true;
	  }
	  void GetPinNo(int pin_no, int& port_no, int& bit_no)
	  {
           port_no = cPinToPort[pin_no];
           bit_no = cPinToBit[pin_no];
	  }
      bool PinInputChanged ( int pin_no, int b_data )
      {
           if ( cPinToPort [ pin_no ] < 0 )return false;

           int port_no = cPinToPort[pin_no];
           int bit_no = cPinToBit[pin_no];

           bool b_success = false;

           if (  parent->P_ReadMemory(iTrisStartAddress+port_no) & ( 1 << bit_no ) )
           {
                 if ( b_data )parent->P_SetMemoryBit(iPortStartAddress+port_no,bit_no);
                 else parent->P_ClearMemoryBit(iPortStartAddress+port_no,bit_no);

                 b_success = true;
           }

           return true;
      }

};

#endif
