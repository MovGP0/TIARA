#include "stdafx.h"
#include "C_SCSimDB.h"
#include <stdlib.h>

#define SIZE_DATA (sizeof(char))
#define SIZE_HEADER (2*sizeof(int))

TSimDB::TSimDB()
{
 n_entries_alloc = n_default_entries;
 last_time = 0; first_run = true; n_entries = 0;
}

TSimDB::~TSimDB()
{
 free(entries);
}

void TSimDB::alloc(int a)
{
 n_signals = a;
 entry_size = sizeof(double)+n_signals*SIZE_DATA;
 entries = (char*)calloc(n_entries_alloc, entry_size);
 update_header();
}

void TSimDB::add_entry(double t, char v, int idx)
{
 char* p;
 char* p_value;

 p = entries;
 p += SIZE_HEADER+(n_entries-1)*entry_size;
 p += sizeof(double);
 p += idx*SIZE_DATA;

 p_value = (char*)p; //!!SIZE_DATA
 *p_value = v;
}

void TSimDB::add_simdb_new_entry(double t)
{
 char* p;
 double* p_time;

 last_time = t; first_run = false;
 n_entries++;
 if (n_entries >= n_entries_alloc) {
  n_entries_alloc += n_default_entries;
  entries = (char*)realloc(entries, n_entries_alloc*entry_size);
 }
 update_header();

 p = entries;
 p += SIZE_HEADER+(n_entries-1)*entry_size;

 p_time = (double*)p;
 *p_time = t;
}

void TSimDB::update_header()
{
 char* p;
 int* p_int;

 p = entries;

 p_int = (int*)p;
 *p_int = n_entries;

 p += sizeof(int);

 p_int = (int*)p;
 *p_int = n_signals;
}

