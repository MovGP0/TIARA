#ifndef picH
#define picH
 
#include "systemc.h"
#include "C_SCPLI.h"
#include "PicSimulator.h"
#include "monitor.h"

#define PORTA 0
#define PORTB 1
#define PORTC 2
#define PORTD 3
#define PORTE 4


SC_MODULE(pic)
{
  sc_inout<sc_logic> VSS, VDD, MCLR;
  sc_inout<sc_logic> RA0, RA1, RA2, RA3, RA4, RA5, RA6, RA7;
  sc_inout<sc_logic> RB0, RB1, RB2, RB3, RB4, RB5, RB6, RB7;
  sc_inout<sc_logic> RC0, RC1, RC2, RC3, RC4, RC5, RC6, RC7;
  sc_inout<sc_logic> RD0, RD1, RD2, RD3, RD4, RD5, RD6, RD7;
  sc_inout<sc_logic> RE0, RE1, RE2, RE3;
  
  sc_signal<sc_logic> clk;  
  
  sc_lv<8> PortA;
  sc_lv<8> PortB;
  sc_lv<8> PortC;
  sc_lv<8> PortD;
  sc_lv<4> PortE;

  monitor MON;

  McuSuperSimulator* simulator = NULL;
  
  double dbSpeed, freq;
  
  void InitSimulator();
  void proc();
  void OnChangePinData(int port_no, int pin, int val);
  void OnWriteSfr(unsigned int sfr_addr, int val, int prev_val);
  void OnWriteSram(unsigned int sram_addr, int val);
  virtual void end_of_elaboration();

  int GETBIT(int a, int n) { return (a>>(n))&1; }
  int invert_bit(int a) { if (a) return 0; else return 1; }
  bool IsTRISAddress(unsigned int sfr_addr, int& port_idx);
  void AddDDRChange(int port_idx, int pin_idx, int val);
  
  
  void clock_proc() 
  {
   int a = simulator->iNanoPerClock/(2*NS);
   while(true) {
    clk.write(SC_LOGIC_0);
    wait(a, SC_NS);
    clk.write(SC_LOGIC_1);
    wait(a, SC_NS);
   }
  }
    
  SC_CTOR(pic): MON("MON")
  {
    SC_THREAD(clock_proc); 
	
    SC_METHOD(proc);
    sensitive << clk;
	
    MON << RA0 << RA1 << RA2 << RA3 << RA4 << RA5 << RA6 << RA7 << RB0 << RB1 << RB2 << RB3 << RB4 << RB5 << RB6 << RB7 << RC0 << RC1 << RC2 << RC3 << RC4 << RC5 << RC6 << RC7;
	MON << RD0 << RD1 << RD2 << RD3 << RD4 << RD5 << RD6 << RD7;
	MON << RE0 << RE1 << RE2 << RE3;
  }
  
};

#endif

