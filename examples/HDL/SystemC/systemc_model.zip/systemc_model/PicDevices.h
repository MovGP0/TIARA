//---------------------------------------------------------------------------

#ifndef PicDevicesH
#define PicDevicesH

#define N_TOKEN_LENGTH 255
#define iAllocation 100

class PicOpcodeList
{
private:
      char strCommand[iAllocation][N_TOKEN_LENGTH];
      char strArgument[iAllocation][N_TOKEN_LENGTH];
      char strOpcode[iAllocation][N_TOKEN_LENGTH];

      int        *iOpcodeID;

      int        iOpcodeIDToEntry[256];

      int  iCurrentSize;
public:
      PicOpcodeList()
      {

           iOpcodeID = new int[iAllocation];

           iCurrentSize = 0;
      }

      void Reset()
      {
           iCurrentSize = 0;
           for ( int i = 0; i < 256; i++ )iOpcodeIDToEntry[i] = -1;
      }

      bool PushOpcode(char* str_command, char* str_argument, char* str_opcode, int opcode_id);
      long GetMatchedOpcode(char* s_opcode, int& i_opcode_id, int& i_param_count, int* i_params );

};


#endif
