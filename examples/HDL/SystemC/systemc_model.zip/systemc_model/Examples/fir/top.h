#ifndef topH
#define topH

#include "fir.h"

SC_MODULE(top)
{
  sc_signal<sc_logic> CLK;
  sc_signal<double> SAMPLE, RESULT;
  
  fir U1;

  SC_CTOR(top): U1("U1")
  {
    U1.CLK(CLK); U1.SAMPLE(SAMPLE); U1.RESULT(RESULT);
  }
};
#endif
