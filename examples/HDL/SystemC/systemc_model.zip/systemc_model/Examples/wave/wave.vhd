library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;

entity sine_saw_wave is
  port ( Clk : in std_logic;
       	 Reset : in std_logic;
         Enable : in std_logic;
         Sel0, Sel1 : in std_logic; -- 0: sine, 1: saw, 2: square wave
         D0 : out std_logic;
         D1 : out std_logic;
         D2 : out std_logic;
         D3 : out std_logic;
         D4 : out std_logic
         );
end sine_saw_wave;


architecture sine_saw_wave_a of sine_saw_wave is

  -- ROM declaration
  constant LUT_index_min: integer := 0;
  constant LUT_index_max: integer := 63;
  type Sine_LUT_typ is array (0 to 63) of std_logic_vector(4 downto 0);
  constant Sine_LUT : Sine_LUT_typ :=("10001","10010","10100","10101","10110","11000","11001","11010",
                                      "11011","11100","11101","11110","11110","11111","11111","11111",
                                      "11111","11111","11111","11110","11110","11101","11100","11011",
                                      "11010","11001","11000","10110","10101","10100","10010","10001",
                                      "01111","01110","01100","01011","01010","01000","00111","00110",
                                      "00101","00100","00011","00010","00010","00001","00001","00001",
                                      "00001","00001","00001","00010","00010","00011","00100","00101",
                                      "00110","00111","01000","01010","01011","01100","01110","01111");  
                                      
  signal LUT_index : integer range 0 to 63;
  signal count_up : std_logic := '1';
  signal Wave : std_logic_vector(4 downto 0);
  
begin

 process(Reset, Clk)
  variable Wave_temp: std_logic_vector(4 downto 0);
 begin
  if (Reset = '1') then
   Wave <= (others => '0');
   LUT_index <= 0;
  elsif rising_edge(Clk) then
   if (Enable = '0') then
    Wave <= (others => '0');
   elsif (Sel0 = '0' and Sel1 = '0') then
    Wave <= Sine_LUT(LUT_index);
   elsif (Sel0 = '1' and Sel1 = '0') then
    Wave <= conv_std_logic_vector(LUT_index,5);
   elsif (Sel0 = '1' and Sel1 = '1') then
    Wave <= (others => '0');
   else
    Wave_temp := conv_std_logic_vector(LUT_index,5);
    Wave_temp(0) := '0';
    Wave_temp(1) := '0';
    Wave_temp(2) := '0';
    Wave_temp(3) := '0';
    Wave <= Wave_temp;
   end if;

   if (LUT_index = LUT_index_max) then
    LUT_index <= 0;
   else
    LUT_index <= LUT_index + 1;
   end if;

  end if;
 end process;

 D0 <= Wave(0);
 D1 <= Wave(1);
 D2 <= Wave(2);
 D3 <= Wave(3);
 D4 <= Wave(4);
	
end sine_saw_wave_a;
