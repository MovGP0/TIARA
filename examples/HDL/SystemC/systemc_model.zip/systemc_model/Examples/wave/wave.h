#ifndef waveH
#define waveH

#include "monitor.h"

#define N_LUT 64
#define LUT_index_max 63

SC_MODULE(wave)
{
  sc_in<sc_logic> Clk, Reset, Enable, Sel0, Sel1;
  sc_out<sc_logic> D0, D1, D2, D3, D4;
  int value;
  
  private:
   int LUT_index;
   
  public:
   monitor MON;

   void proc();
  
   SC_CTOR(wave): MON("MON")
   {
     value = 0; LUT_index = 0;
     SC_METHOD(proc);
     sensitive << Reset << Clk;
     MON << D0 << D1 << D2 << D3 << D4;
   }
};
#endif

