#INCLUDE <P16LF1906.INC>

X1      EQU     20H

 ; start of code (reset vector)
RESETV   CODE    0x0000      ; processor reset vector
    goto    start

; main program
MAIN

start
 MOVLW 		1
 MOVWF 		BSR
 MOVLW      0
 MOVWF      TRISA
 MOVLW      0FFH
 MOVWF      TRISB 
 MOVLW 		0
 MOVWF 		BSR
 
FLOWCHART_LABEL3:             
 MOVF  	     PORTB, W         ;X1 <- PORTB
 MOVWF       X1

 MOVF        X1, W
 MOVWF       PORTA            ;PORTA <- X1

 GOTO        FLOWCHART_LABEL3
 

 goto start
END


 


