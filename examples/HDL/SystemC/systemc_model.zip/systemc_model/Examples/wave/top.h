#ifndef topH
#define topH

#include "wave.h"

SC_MODULE(top)
{
  sc_signal<sc_logic> Clk, Reset, Enable, Sel0, Sel1, D0, D1, D2, D3, D4;
  
  wave U1;

  SC_CTOR(top): U1("U1")
  {
    U1.Clk(Clk); U1.Reset(Reset); U1.Enable(Enable); U1.Sel0(Sel0); U1.Sel1(Sel1); U1.D0(D0); U1.D1(D1); U1.D2(D2); U1.D3(D3); U1.D4(D4); 
  }
};
#endif

