#ifndef topH
#define topH

#include "pic.h"

SC_MODULE(top)
{
  sc_signal<sc_logic> MCLR, RA0, RA1, RA2, RA3, RA4, RA5, VSS, RA7, RA6, RC0, RC1, RC2, RC3;
  sc_signal<sc_logic> RB7, RB6, RB5, RB4, RB3, RB2, RB1, RB0, VDD, RC7, RC6, RC5, RC4;
  
  pic U1;

  SC_CTOR(top): U1("U1")
  {
    U1.RA0(RA0); U1.RA1(RA1); U1.RA2(RA2); U1.RA3(RA3); U1.RA4(RA4); U1.RA5(RA5); U1.RA6(RA6); U1.RA7(RA7);  
    U1.RB0(RB0); U1.RB1(RB1); U1.RB2(RB2); U1.RB3(RB3); U1.RB4(RB4); U1.RB5(RB5); U1.RB6(RB6); U1.RB7(RB7); 
    U1.RC0(RC0); U1.RC1(RC1); U1.RC2(RC2); U1.RC3(RC3); U1.RC4(RC4); U1.RC5(RC5); U1.RC6(RC6); U1.RC7(RC7); 
	U1.VSS(VSS); U1.VDD(VDD); U1.MCLR(MCLR); 
  }
};

#endif

