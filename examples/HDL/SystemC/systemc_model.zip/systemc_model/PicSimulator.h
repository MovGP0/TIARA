#ifndef PicSimulatorH
#define PicSimulatorH 
 
#include "SuperSimulator.h"
#include "PicDevices.h"
#include "PicDrivers.h"

#define PIC_DEVICE_MAXIMUM_PORT_COUNT   5
#define PIC_DEVICE_MAXIMUM_PIN_COUNT    100
#define PIC_DEVICE_MEMORY_SIZE          512
#define PIC_DEVICE_EEPROM_SIZE          256

#define TRISA 0x8C
#define TRISB 0x8D
#define TRISC 0x8E



typedef enum
{
    PIC_OPCODE_ADDWF = 0,    PIC_OPCODE_ANDWF,    PIC_OPCODE_CLRF,    PIC_OPCODE_CLRW,    PIC_OPCODE_COMF,    PIC_OPCODE_DECF,    PIC_OPCODE_DECFSZ,
    PIC_OPCODE_INCF,         PIC_OPCODE_INCFSZ,   PIC_OPCODE_IORWF,   PIC_OPCODE_MOVF,    PIC_OPCODE_MOVWF,   PIC_OPCODE_NOP,     PIC_OPCODE_RLF,
    PIC_OPCODE_RRF,          PIC_OPCODE_SUBWF,    PIC_OPCODE_SWAPF,   PIC_OPCODE_XORWF,   PIC_OPCODE_BCF,     PIC_OPCODE_BSF,     PIC_OPCODE_BTFSC,
    PIC_OPCODE_BTFSS,        PIC_OPCODE_ADDLW,    PIC_OPCODE_ANDLW,   PIC_OPCODE_CALL,    PIC_OPCODE_CLRWDT,  PIC_OPCODE_GOTO,    PIC_OPCODE_IORLW,
    PIC_OPCODE_MOVLW,        PIC_OPCODE_RETFIE,   PIC_OPCODE_RETLW,   PIC_OPCODE_RETURN,  PIC_OPCODE_SLEEP,   PIC_OPCODE_SUBLW,   PIC_OPCODE_XORLW,
	PIC_OPCODE_TRIS,         PIC_OPCODE_OPTION,

	PIC_OPCODE_MOVLB,        PIC_OPCODE_LSRF,     PIC_OPCODE_LSLF,    PIC_OPCODE_MOVLP,   PIC_OPCODE_ADDWFC,  PIC_OPCODE_SUBWFB

} t_pic_opcode_id;

class PicSimulator : public McuSuperSimulator,McuPeripheralUser
{
 private:
      enum { MAX_SRAM_BLOCK_COUNT = 50 };
	  
      BYTE            cMemory[PIC_DEVICE_MEMORY_SIZE];      // 128 in each of four banks
      BYTE            cPinData[PIC_DEVICE_MAXIMUM_PIN_COUNT];
      BYTE            cPinStatus[PIC_DEVICE_MAXIMUM_PIN_COUNT]; //0-INPUT,1-OUTPUT,2-HIGH Z

      bool            bValidMemory[PIC_DEVICE_MEMORY_SIZE];
      bool            bValidSfr[PIC_DEVICE_MEMORY_SIZE];
      int             iMemoryTransform[PIC_DEVICE_MEMORY_SIZE];

      PicOpcodeList   opcode_list;
      PicPortDriver   portDriver;
	  
      bool            bInterrupt;
      int             iPortCount;

      int       iInstructionLengthInBit;
      int       iDataMemSize;
      double    fFrequencyMHZ;
      double    fVccMIN;
      double    fVccMax;

      BYTE      cWValue;

      int  iSramBlockStart[MAX_SRAM_BLOCK_COUNT];
      int  iSramBlockEnd[MAX_SRAM_BLOCK_COUNT];
      int  iSramBlockCount;

      int  iConfigValue;
	  
	  
      int iPcMaximum;
      int iPcStack[8];
      int iPcStackDepth;

      int iBsrAddress, iCommonRAMStart, iCommonRAMEnd, iWregAddress;          
      int iStatusAddress;
      int iPclAddress;
      int iPclathAddress;
      int iOptionAddress;
      int iIntconAddress;
      int iFsrAddress;
      int iPconAddress;
      int iPie1Address;
      int iPir1Address;
      int iPie2Address;
      int iPir2Address;

      int iAvccPin;
      int iAgndPin;
      int iVrefPin;

      double fPrevVccVoltage;                      // For BOR and POR detection

	  
      void Load14Bit35InstructionSet();
	  
      void CreateDevice(long instruction_length_in_bit,long flash_size,long eeprom_size,long data_mem_size,double frequency_mega_hertz,double vcc_min,double vcc_max);
	  
	  
      void AddSramBlock(int start_addr,int end_addr)
      {
           if ( iSramBlockCount >= MAX_SRAM_BLOCK_COUNT )return;

           if ( start_addr < 0 || end_addr < 0 || start_addr >= PIC_DEVICE_MEMORY_SIZE || end_addr >= PIC_DEVICE_MEMORY_SIZE )return;

           iSramBlockStart[iSramBlockCount] = start_addr;
           iSramBlockEnd[iSramBlockCount]   = end_addr;

           iSramBlockCount++;

           for ( int i = start_addr; i <= end_addr; i++ )
           {
                 bValidMemory[i] = true;
                 bValidSfr[i]    = false;
           }
      }
      void AddTransformBlock(int start_addr,int end_addr,int target_addr)
      {
           for ( int i = start_addr; i <= end_addr; i++ )
           {
                 if ( i >= PIC_DEVICE_MEMORY_SIZE )return;

                 iMemoryTransform[i] = i + target_addr - start_addr;
                 if ( iMemoryTransform[i] < 0 )iMemoryTransform[i] = 0;
                 if ( iMemoryTransform[i] >= PIC_DEVICE_MEMORY_SIZE )iMemoryTransform[i] = PIC_DEVICE_MEMORY_SIZE - 1;
           }
      }
	  
      void SetMemValue(int mem_addr,BYTE val,bool b_external_write = false);
	  
      BYTE GetMemValue(int mem_addr,bool b_external_read = false)
      {
           if ( mem_addr < 0 || mem_addr >= PIC_DEVICE_MEMORY_SIZE )return 0;

           //if ( iInstructionLengthInBit == 12 )return GetMemValue33InstructionSet(mem_addr,b_external_read);

           if ( ( mem_addr & 0x7F ) == 0 )
           {
                mem_addr = cMemory [ iFsrAddress ];
                if ( cMemory [ iStatusAddress ] & 0x80 )mem_addr += 0x100;
           }
		   else if ( !b_external_read && iBsrAddress == -1 )mem_addr += ( ( cMemory [ iStatusAddress ] & 0x60 ) / 0x20 ) * 0x80;
		   else if ( !b_external_read && iBsrAddress != -1 && mem_addr != iBsrAddress && (mem_addr < iCommonRAMStart || mem_addr > iCommonRAMEnd) ) mem_addr += ( cMemory [ iBsrAddress ] & 0x1F ) * 128;

           mem_addr = iMemoryTransform[mem_addr];
           //if ( !bValidMemory[mem_addr] )listener->OnError(ERROR_READ_FROM_BAD_LOCATION);

           //usartDriver.MemoryReadSpecial(mem_addr); // 22 DEC 06

           return cMemory[mem_addr];
      }
	  
      void NotifyMemoryChangeToPeripherals(long mem_addr,BYTE c_val)
      {
           bool b_res = false;

           if ( portDriver.MemoryChanged(mem_addr,c_val) )b_res = true;

           if ( !b_res )cMemory[mem_addr] = c_val;
           else if ( mem_addr == iOptionAddress || mem_addr == iPie1Address || mem_addr == iPie2Address || mem_addr == iStatusAddress || mem_addr == iPclAddress || mem_addr == iPclathAddress )cMemory [ mem_addr ] = c_val;
      }
	  
      void SetZeroFlag(bool b_value)
      {
           if ( b_value )
                cMemory [ iStatusAddress ] |= 0x04;
           else cMemory [ iStatusAddress ] &= ( 0xFF - 0x04 );

           //listener->OnWriteSfr(iStatusAddress,cMemory[iStatusAddress]);
      }
      bool GetZeroFlag()
      {
           if ( cMemory [ iStatusAddress ] & 0x04 )return true;
           return false;
      }
      void SetCarryFlag(bool b_value)
      {
           if ( b_value )cMemory [ iStatusAddress ] |= 0x01;
           else cMemory [ iStatusAddress ] &= ( 0xFF - 0x01 );

           //listener->OnWriteSfr(iStatusAddress,cMemory[iStatusAddress]);
      }
      void SetDigitCarryFlag(bool b_value)
      {
           if ( b_value )cMemory [ iStatusAddress ] |= 0x02;
           else cMemory [ iStatusAddress ] &= ( 0xFF - 0x02 );

           //listener->OnWriteSfr(iStatusAddress,cMemory[iStatusAddress]);
      }
      bool GetCarryFlag()
      {
           if ( cMemory [ iStatusAddress] & 0x01 )return true;
           return false;
      }

      int Me_GetCurrentInstructionNecessaryCycle();
      virtual void ExecuteCurrentInstructionOnly();
	  
 public:
      BYTE P_ReadMemory(int mem_addr)
      {
           if ( mem_addr < 0 || mem_addr >= PIC_DEVICE_MEMORY_SIZE )return 0;
           return cMemory[mem_addr];
      }
      void P_WriteMemory(int mem_addr,BYTE val)
      {
           if ( mem_addr < 0 || mem_addr >= PIC_DEVICE_MEMORY_SIZE )return;
           //if ( cMemory [ mem_addr ] != val )listener->OnWriteSfr(mem_addr,val);
           cMemory [ mem_addr ] = val;
      }
      bool P_GetPinData(int pin_no)
      {
           if ( pin_no < 0 || pin_no >= iPinCount )return false;
           return ( fPinVolt[pin_no] >= 0.8 );
      }
	  void P_SetPinData(int pin_no, bool val, bool from_port_driver = false);
      bool P_GetPinStatus(int pin_no)
      {
           if ( pin_no < 0 || pin_no >= iPinCount )return false;
           if ( cPinStatus[pin_no] & 0x01 )return true;           
           return false;
      }
      void P_SetPinStatus(int pin_no,bool st)
      {
           if ( pin_no < 0 || pin_no >= iPinCount )return;

           if ( st )cPinStatus[pin_no] |= 1;
           else cPinStatus[pin_no] &= ( 0xFF - 0x01 );

           //listener->OnChangePinStatus(pin_no,st);
      }
	  
      void P_SetMemoryBit(int mem_addr,int bit_pos)
      {
           if ( mem_addr < 0 || mem_addr >= PIC_DEVICE_MEMORY_SIZE )return;
           BYTE prev_val = cMemory [ mem_addr ];
           cMemory [ mem_addr ] |= ( 1 << bit_pos );
           //if ( prev_val != cMemory [ mem_addr ] )listener->OnWriteSfr ( mem_addr, cMemory [ mem_addr ] );
      }

      void P_ClearMemoryBit(int mem_addr,int bit_pos)
      {
           if ( mem_addr < 0 || mem_addr >= PIC_DEVICE_MEMORY_SIZE )return;
           BYTE prev_val = cMemory [ mem_addr ];
           cMemory [ mem_addr ] &= ( 0xFF - ( 1 << bit_pos ) );
           //if ( prev_val != cMemory [ mem_addr ] )listener->OnWriteSfr ( mem_addr, cMemory [ mem_addr ] );
      }
	  
      PicSimulator();
 
      int  GetSimulatorType() { return MCU_SIMULATOR_TYPE_PIC; }
      void LoadHEXFile(char *fn);
      bool SetDevice();
      bool StartSimulation();
      void SetPinDataX(int pin_no, int val);
  
  
};


#endif
