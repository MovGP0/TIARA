#include "stdafx.h"
#include "SuperSimulator.h"
#include "sc_pli_classes.h"
#include "C_SCPLI.h"
#include "string_util.h"


const __int64 FS     = 1;
const __int64 PS     = 1000*FS;
const __int64 NS     = 1000*PS;
const __int64 US     = 1000*NS;
const __int64 MS     = 1000*US;
const __int64 Second = 1000*MS;
const __int64 Minute = 60*Second;
const __int64 Hour   = 60*Minute;

const __int64 NS_MCU = 1;
const double CALC_MCU_PERIOD = 1000.0*NS; //do not change NS here

McuSuperSimulator::McuSuperSimulator()
{
 iFlashCode = NULL;
 iFlashOpcodeID = NULL;
 iFlashOpcodeParam1 = NULL;
 iFlashOpcodeParam2 = NULL;
 iFlashOpcodeParam3 = NULL;

 fPCChanged = fPCChangedSim = fTimeChanged = fNodeChanged = fStartFinished = bSquareLayout = false; fStopMCUInstrCount = iMCUInstrExecuted = iMCUInstrSessionExecuted = 0;
 iInitPCVal = 0; iCurrentPC = 0; 

 fSpeed = 1; MCLK_DIV = 1; 
 
 iVccPin = 0;
 iGndPin = 1;
 iResetPin = 2;
}

void McuSuperSimulator::OnTimeChange()
{
 for ( int i = 0; i < iChangedPinCount; i++ ) SetPinDataX(iChangedPinIndex[i], bChangedPinLevel[i]);

 iCycleCountDown--;
 if ( iCycleCountDown <= 0 )
 {
      ExecuteCurrentInstructionOnly();
	  iCycleCountDown = iCurrentInstructionNecessaryCycle;
      if ( iSimulatorType == MCU_SIMULATOR_TYPE_PIC || iSimulatorType == ( MCU_SIMULATOR_TYPE_PIC + 100 ) )
      {
           iCycleCountDown *= 4;
      }
      else if ( iSimulatorType == MCU_SIMULATOR_TYPE_PIC_24 )iCycleCountDown *= 2;
      iInstructionExecuted++;
 }

 iLastNanoTime += iNanoPerClock;
 iCurrentCycle++;
 
 sc_pli_mcu_clear_changes();

}

bool McuSuperSimulator::StartSimulationEnv(double speed_mhz)
{
 if ( speed_mhz <= 0 ) return false;

 fSpeed = speed_mhz;
 iSimulatorType = GetSimulatorType();
 iNanoPerClock = CALC_MCU_PERIOD / speed_mhz;

 iLastNanoTime = 0;

 bSleeping = false;

 iCurrentPC = 0;
 iCurrentCycle = 0;
 iInstructionExecuted = 0;

 bool b_ret = StartSimulation();
 iCycleCountDown = iCurrentInstructionNecessaryCycle;
 if ( iSimulatorType == MCU_SIMULATOR_TYPE_PIC || iSimulatorType == ( MCU_SIMULATOR_TYPE_PIC + 100 ) )iCycleCountDown *= 4;
 else if ( iSimulatorType == MCU_SIMULATOR_TYPE_PIC_24 )iCycleCountDown *= 2;

 //listener->OnChangePC ( iCurrentPC );
 fStartFinished = true;

 return b_ret;
}

void McuSuperSimulator::SetPinLayout(char* s_layout_, bool b_square_layout )
{
	        char s_layout[2048], buf[2048]; StrUpperCase(s_layout_, s_layout);
            bSquareLayout = b_square_layout;

            iPinCount = 0;
            int st = 0;
            int comma_pos = -1;
            int first_bracet_start;
			int first_bracet_end;

            char s_pin[256], s_alternative[256]; int L = strlen(s_layout);

            for ( int i = 1; i <= L; i++ )
            {
                  if ( s_layout[i-1] == '[' )st = i + 1;
                  else if ( s_layout[i-1] == ']' && st >= 1 )
                  {
                       char* s1 = StrSubString(s_layout, buf, st, i - st );
                       if ( ( first_bracet_start = StrPos("(", s1) ) >= 1 )
                       {
                              first_bracet_end = StrPos(")", s1);
                              StrSubString ( s1, s_alternative, first_bracet_start + 1, first_bracet_end - first_bracet_start - 1 );

                              if ( first_bracet_start > 1 ) StrSubString(s1, s_pin, 1,first_bracet_start-1);
                              else StrSubString(s1, s_pin, first_bracet_end + 1, strlen(s1) - first_bracet_end );
                       }
                       else if ( ( comma_pos = StrPos(",", s1) ) > 1 )
                       {
                              StrSubString ( s1, s_pin, 1 , comma_pos - 1 );
                              StrSubString ( s1, s_alternative, comma_pos + 1, strlen(s1) - comma_pos );
                       }
                       else
                       {
                              strcpy(s_pin, s1);
                              strcpy(s_alternative, "");
                       }

                       if ( strlen(s_pin) )
                       {
                              if ( iPinCount >= MAXIMUM_PIN_COUNT )break;

                              strcpy(strPinNames[iPinCount][0], s_pin);
                              iPinAlternativeCount[iPinCount] = 0;

                              strcat(s_alternative, ",");
                              int prev_pos = 1;

                              for ( int j = 2; j <= strlen(s_alternative); j++ )
                              {
                                    if ( s_alternative[j-1] == ',' || s_alternative[j-1] == '/' || s_alternative[j-1] == '\\' );
                                    else continue;

                                    StrSubString(s_alternative, strPinNames[iPinCount][iPinAlternativeCount[iPinCount]+1], prev_pos,j-prev_pos);
                                    iPinAlternativeCount[iPinCount]++;

                                    prev_pos = j+1;
                              }
                              iPinCount++;
                       }
                  }
			}

            for ( int i = 0; i < iPinCount; i++ )iPinMapping[i] = i;
            for ( int i = 0; i < iPinCount; i++ )
            {
                  if ( StrPos("_", strPinNames[i][0]) > 0 )continue;
                  int tmp = 2;
                  for ( int j = i+1; j < iPinCount; j++ )
                  {
                        if ( !strcmp(strPinNames[j][0], strPinNames[i][0]) )
                        {
                             iPinMapping[j] = i;
                             strcat(strPinNames[j][0], "_"); buf[0] = (int)tmp; buf[1] = '\0';
                             strcat(strPinNames[j][0], buf);
                             tmp++;
                        }
                  }
            }

            iVccPin = PinIndexFromName("VCC");
            if ( iVccPin < 0 )iVccPin = PinIndexFromName("VDD");
            if ( iVccPin < 0 )iVccPin = PinIndexFromName("VPP");
            if ( iVccPin < 0 )iVccPin = PinIndexFromName("VDDCORE");

			iGndPin = PinIndexFromName("VSS");
            if ( iGndPin < 0 )iGndPin = PinIndexFromName("GND");

            if ( ( iResetPin = PinIndexFromName("MCLR") ) >= 0 )
            {
                   if ( strcmp(PinNameFromIndex(iResetPin), "MCLR") )iResetPin = -1;
            }
            else if ( ( iResetPin = PinIndexFromName("RESET") ) >= 0 )
            {
                   if ( strcmp(PinNameFromIndex(iResetPin), "RESET") )iResetPin = -1;
            }
            else if ( ( iResetPin = PinIndexFromName("RST") ) >= 0 )
            {
                   if ( strcmp(PinNameFromIndex(iResetPin), "RST") )iResetPin = -1;
            }

			
            for ( int i = 0; i < iPinCount; i++ ) {
                pli_interface_class* i_node;
				
                i_node = (pli_interface_class*)find_interface_node(strPinNames[i][0]);
				if (i_node)
				 i_node->pin_no = i;
			}

}

int McuSuperSimulator::PinIndexFromName(char* s_name)
{
                   for ( int i = 0; i < iPinCount; i++ )
                   {
                         for ( int j = 0; j < iPinAlternativeCount[i] + 1; j++ )
                         if ( !strcmp(strPinNames[i][j], s_name) )return i;
                   }
                   return -1;
}

