#ifndef gatesH
#define gatesH

#include "systemc.h"

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(and2)
{
  sc_in<sc_logic> I1, I2;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = I1.read() & I2.read();
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(and2)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(and3)
{
  sc_in<sc_logic> I1, I2, I3;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = I1.read() & I2.read() & I3.read();
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(and3)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2 << I3;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(and4)
{
  sc_in<sc_logic> I1, I2, I3, I4;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = I1.read() & I2.read() & I3.read() & I4.read();
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(and4)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2 << I3 << I4;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(and5)
{
  sc_in<sc_logic> I1, I2, I3, I4, I5;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = I1.read() & I2.read() & I3.read() & I4.read() & I5.read();
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(and5)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2 << I3 << I4 << I5;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(or2)
{
  sc_in<sc_logic> I1, I2;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = I1.read() | I2.read();
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(or2)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(or3)
{
  sc_in<sc_logic> I1, I2, I3;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = I1.read() | I2.read() | I3.read();
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(or3)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2 << I3;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(or4)
{
  sc_in<sc_logic> I1, I2, I3, I4;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = I1.read() | I2.read() | I3.read() | I4.read();
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(or4)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2 << I3 << I4;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(or5)
{
  sc_in<sc_logic> I1, I2, I3, I4, I5;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = I1.read() | I2.read() | I3.read() | I4.read() | I5.read();
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(or5)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2 << I3 << I4 << I5;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(nand2)
{
  sc_in<sc_logic> I1, I2;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = ~(I1.read() & I2.read());
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(nand2)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(nand3)
{
  sc_in<sc_logic> I1, I2, I3;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = ~(I1.read() & I2.read() & I3.read());
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(nand3)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2 << I3;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(nand4)
{
  sc_in<sc_logic> I1, I2, I3, I4;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = ~(I1.read() & I2.read() & I3.read() & I4.read());
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(nand4)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2 << I3 << I4;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(nand5)
{
  sc_in<sc_logic> I1, I2, I3, I4, I5;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = ~(I1.read() & I2.read() & I3.read() & I4.read() & I5.read());
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(nand5)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2 << I3 << I4 << I5;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(nor2)
{
  sc_in<sc_logic> I1, I2;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = ~(I1.read() | I2.read());
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(nor2)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(nor3)
{
  sc_in<sc_logic> I1, I2, I3;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = ~(I1.read() | I2.read() | I3.read());
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(nor3)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2 << I3;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(nor4)
{
  sc_in<sc_logic> I1, I2, I3, I4;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = ~(I1.read() | I2.read() | I3.read() | I4.read());
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(nor4)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2 << I3 << I4;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(nor5)
{
  sc_in<sc_logic> I1, I2, I3, I4, I5;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = ~(I1.read() | I2.read() | I3.read() | I4.read() | I5.read());
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(nor5)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2 << I3 << I4 << I5;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(xorg)
{
  sc_in<sc_logic> I1, I2;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = I1.read() ^ I2.read();
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(xorg)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(xnorg)
{
  sc_in<sc_logic> I1, I2;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = ~(I1.read() ^ I2.read());
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(xnorg)
  {
    SC_THREAD(proc);
    sensitive << I1 << I2;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(notg)
{
  sc_in<sc_logic> I1;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = ~(I1.read());
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(notg)
  {
    SC_THREAD(proc);
    sensitive << I1;
  }
};

template <int tpLH = 0, int tpHL = 0>
SC_MODULE(buf)
{
  sc_in<sc_logic> I1;
  sc_out<sc_logic> Q;

  void proc()
  {
    sc_logic var_a;
    while (true)
    {
      wait();
      var_a = I1.read();
      if (var_a == SC_LOGIC_1) wait(tpLH, SC_NS); else wait(tpHL, SC_NS);
      Q.write(var_a);
    }
  }

  SC_CTOR(buf)
  {
    SC_THREAD(proc);
    sensitive << I1;
  }
};

#endif

