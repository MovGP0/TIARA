#include "stdafx.h"
#include "fir.h"
#include "util.h"


const double b[M] = {
  0.048235307233685576,
  0.08951102381509493,
  0.14483365475957452,
  0.194344468218107,
  0.22373075953786237,
  0.22373075953786237,
  0.194344468218107,
  0.14483365475957452,
  0.08951102381509493,
  0.048235307233685576
 };

void fir::proc()
{
 double u, y;
 
 if (CLK.read() == SC_LOGIC_1) {
  sc_logic sc_val;
   
  // CALC
  x[0] = SAMPLE; y = 0;
  for (int k=0; k<M; k++) {
   y += b[k]*x[k];
  } 
  
  // SHIFT
  for (int k=M-1; k>=1; k--) 
   x[k] = x[k-1];
  
  // SET VALUE
  RESULT = y;
  
  n++;

  #ifdef DEBUG
  debug.open(debug_file_name, std::ofstream::out | std::ofstream::app);
  debug << "After time change: " << sc_get_curr_simcontext()->time_stamp().to_string();
  debug << "x[0]: ";
  debug  << x[0] << endl;
  debug.close();
  #endif
 }
}
