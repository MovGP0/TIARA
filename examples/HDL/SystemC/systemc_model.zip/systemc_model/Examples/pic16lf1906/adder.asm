#INCLUDE <P16LF1906.INC>

X       EQU     20H
Y       EQU     21H
Z1      EQU     22H

 ; start of code (reset vector)
RESETV   CODE    0x0000      ; processor reset vector
    goto    start

; main program
MAIN

start
 MOVLW 		1
 MOVWF 		BSR
 MOVLW      0FFH
 MOVWF      TRISA
 MOVWF      TRISB
 MOVLW 		0
 MOVWF      TRISC
 MOVWF 		BSR

FLOWCHART_LABEL2:             ;X <- PORTA
 MOVF  	PORTA, W
 MOVWF 	X

FLOWCHART_LABEL3:             ;Y <- PORTB
 MOVF  	PORTB, W
 MOVWF 	Y

FLOWCHART_LABEL4:             ;Z1 = X
 MOVF  	X, W
 MOVWF 	Z1

FLOWCHART_LABEL5:             ;Z1 = Z1 + Y
 MOVF  	Y, W
 ADDWF 	Z1, F

FLOWCHART_LABEL6:             ;PORTC <- Z1
 MOVF  	Z1, W
 MOVWF 	PORTC 
 GOTO  	FLOWCHART_LABEL2

END
