#ifndef monitorH
#define monitorH

#include "systemc.h"
#include "C_SCPLI.h"

SC_MODULE(monitor)
{
  sc_out<double> RESULT;

  SC_CTOR(monitor)
  {
    SC_METHOD(proc);
    sensitive << RESULT;
  }

  void proc()
  {
    sc_pli_set_node_changed(true);
    sc_pause();
  }
};
#endif

