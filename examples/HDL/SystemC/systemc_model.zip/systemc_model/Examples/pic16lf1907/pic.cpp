#include "stdafx.h"
#include "pic.h"
#include "util.h"


void pic::InitSimulator()
{
 simulator = new PicSimulator;
 freq = mcu_freq;
 dbSpeed = freq/1e6;
 simulator->SetListener( (char*)this );
 
 #ifdef DEBUG
 debug.open(debug_file_name, std::ofstream::out);
 debug  << "InitSimulator" << endl;
 debug.close();
 #endif
	
 bool b_ret = simulator->StartSimulationEnv(dbSpeed);
}

void pic::end_of_elaboration()
{
 InitSimulator();
}

void pic::proc()
{
 if (clk.read() == SC_LOGIC_1) {
  int tris, val;
  sc_logic sc_val;
  
  sc_pli_connect(); // to avoid some linker problem in Visual Studio
  
  simulator->OnTimeChange(); 
 
  #ifdef DEBUG
  debug.open(debug_file_name, std::ofstream::out | std::ofstream::app);
  debug << "After OnTimeChange: " << sc_get_curr_simcontext()->time_stamp().to_string() << endl;
  debug.close();
  #endif
 }
}

void pic::OnChangePinData(int port_no, int pin, int val)
{
 sc_logic sc_val;
 
 if (val == 1) sc_val = SC_LOGIC_1; else sc_val = SC_LOGIC_0;

 if (port_no == PORTA) 
  PortA[pin] = sc_val;
 else if (port_no == PORTB) 
  PortB[pin] = sc_val;
 else if (port_no == PORTC)
  PortC[pin] = sc_val;
 else if (port_no == PORTD)
  PortD[pin] = sc_val;
 else if (port_no == PORTE)
  PortE[pin] = sc_val;
 
 
 RA0 = PortA[0];
 RA1 = PortA[1];
 RA2 = PortA[2];
 RA3 = PortA[3];
 RA4 = PortA[4];
 RA5 = PortA[5];
 RA6 = PortA[6];
 RA7 = PortA[7];
 
 RB0 = PortB[0];
 RB1 = PortB[1];
 RB2 = PortB[2];
 RB3 = PortB[3];
 RB4 = PortB[4];
 RB5 = PortB[5];
 RB6 = PortB[6];
 RB7 = PortB[7];
 
 RC0 = PortC[0];
 RC1 = PortC[1];
 RC2 = PortC[2];
 RC3 = PortC[3];
 RC4 = PortC[4];
 RC5 = PortC[5];
 RC6 = PortC[6];
 RC7 = PortC[7];
 
 RD0 = PortD[0];
 RD1 = PortD[1];
 RD2 = PortD[2];
 RD3 = PortD[3];
 RD4 = PortD[4];
 RD5 = PortD[5];
 RD6 = PortD[6];
 RD7 = PortD[7];
 
 RE0 = PortE[0];
 RE1 = PortE[1];
 RE2 = PortE[2];
 RE3 = PortE[3];
}

bool pic::IsTRISAddress(unsigned int sfr_addr, int& port_idx)
{
	port_idx = 0;
	
	if (sfr_addr == TRISA) {
		port_idx = 0;
		return true; 
	}
	else if (sfr_addr == TRISB) {
		port_idx = 1;
		return true; 
	}
	else if (sfr_addr == TRISC) {
		port_idx = 2;
		return true; 
	}
	else if (sfr_addr == TRISD) {
		port_idx = 3;
		return true; 
	}
	else if (sfr_addr == TRISE) {
		port_idx = 4;
		return true; 
	}
	else
		return false;
	
}

void pic::AddDDRChange(int port_idx, int pin_idx, int val)
{
	t_ddr_change* a = &ddr_changes[iDDRChangeCount];
	
	a->idx = pin_idx;
	a->dir = val;
	wcscpy(a->name, PortDesignators[port_idx]);
	
	iDDRChangeCount++;
}

void pic::OnWriteSfr(unsigned int sfr_addr, int val, int prev_val)
{
 int i, old_bit, new_bit, port_idx;
 
 if (IsTRISAddress(sfr_addr, port_idx)) {
  for (i=0; i<16; i++) {
   old_bit = GETBIT(prev_val, i);
   new_bit = GETBIT(val, i);
     
   if (old_bit != new_bit) {
	   new_bit = invert_bit(new_bit);
	   AddDDRChange(port_idx, i, new_bit);
   }	   
	    
  }		
 }
}

void pic::OnWriteSram(unsigned int sram_addr, int val)
{
}

