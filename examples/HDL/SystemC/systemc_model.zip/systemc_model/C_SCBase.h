#ifndef C_SCBaseH
#define C_SCBaseH

#include "systemc.h"

typedef uint64 vtime;

#endif
