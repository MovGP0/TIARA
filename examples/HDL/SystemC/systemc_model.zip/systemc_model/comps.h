#ifndef compsH
#define compsH

#include "gates.h"
#include "flipflops.h"

#endif

