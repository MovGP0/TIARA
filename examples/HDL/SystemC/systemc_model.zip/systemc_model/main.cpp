#include "stdafx.h"
#include "top.h"

int sc_main(int argc, char* argv[])
{
  top* TOP = new top("TOP");

  return 0;
}
