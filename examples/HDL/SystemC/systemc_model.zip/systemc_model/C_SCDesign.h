#ifndef C_SCDesignH
#define C_SCDesignH

#include <stdio.h>

class TSCDesign {
private:
public:
 TSCDesign();
 ~TSCDesign();
};

extern TSCDesign* design;

#endif
