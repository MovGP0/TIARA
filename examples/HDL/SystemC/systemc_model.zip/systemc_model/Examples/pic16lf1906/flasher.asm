#INCLUDE <P16LF1906.INC>

X1      EQU     20H

 ; start of code (reset vector)
RESETV   CODE    0x0000      ; processor reset vector
    goto    start

; main program
MAIN

start
 MOVLW 		1
 MOVWF 		BSR
 MOVLW      0
 MOVWF      TRISA
 MOVLW 		0
 MOVWF 		BSR
 
 MOVLW       0
 MOVWF       X1

FLOWCHART_LABEL3:             ;PORTA <- X1
 MOVF        X1, W
 MOVWF       PORTA 

FLOWCHART_LABEL4:             ;X1 = X1 + 1
 MOVLW       1
 ADDWF       X1, F
 GOTO        FLOWCHART_LABEL3
 

 goto start
END


 


