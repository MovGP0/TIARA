@echo off
rd /s /q debug
rd /s /q ipch
del *.sdf

cd pli
rd /s /q debug

cd ..\systemc_model
rd /s /q debug

cd ..\systemc_model_app
rd /s /q debug

cd ..
