#include "stdafx.h"
#include "wave.h"
#include "util.h"

const int Sine_LUT[N_LUT] = {
  17, 18, 20, 21, 22, 24, 25, 26,
  27, 28, 29, 30, 30, 31, 31, 31,
  31, 31, 31, 30, 30, 29, 28, 27,
  26, 25, 24, 22, 21, 20, 18, 17,  
  15, 14, 12, 11, 10, 8, 7, 6,  
  5, 4, 3, 2, 2, 1, 1, 1,  
  1, 1, 1, 2, 2, 3, 4, 5,   
  6, 7, 8, 10, 11, 12, 14, 15
};

void wave::proc()
{
 if (Reset.event() && Reset == SC_LOGIC_1) {
  value = 0;
  LUT_index = 0;
 }
 else if (Clk.event() && Clk == SC_LOGIC_1) {
  if (Enable == SC_LOGIC_0) 
   value = 0;
  else if (Sel0 == SC_LOGIC_0 && Sel1 == SC_LOGIC_0)
   value = Sine_LUT[LUT_index];
  else if (Sel0 == SC_LOGIC_1 && Sel1 == SC_LOGIC_0)
   value = LUT_index;
  else if (Sel0 == SC_LOGIC_1 && Sel1 == SC_LOGIC_1)
   value = 0;
  else {
   value = LUT_index;
   value &= 0x10;
  }
  
  if (LUT_index == LUT_index_max) 
   LUT_index = 0;
  else
   LUT_index++;	  
  
 }
 
 sc_lv<5> sclv_value(value);
 D0 = sclv_value[0];
 D1 = sclv_value[1];
 D2 = sclv_value[2];
 D3 = sclv_value[3];
 D4 = sclv_value[4];
}

