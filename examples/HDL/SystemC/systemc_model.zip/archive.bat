"c:\Program Files (x86)\Git\bin\git" archive -o systemc_model.zip HEAD
