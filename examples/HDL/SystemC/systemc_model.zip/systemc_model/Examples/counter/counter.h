#ifndef counterH
#define counterH

#include "monitor.h"

SC_MODULE(counter)
{
  sc_in<sc_logic> CLK, CLEAR;
  sc_out<sc_logic> QA, QB, QC, QD;
  int value;
  
  monitor MON;

  void proc() 
  { 
   double t = sc_get_curr_simcontext()->time_stamp().to_seconds();
   if (CLEAR.event() && CLEAR == SC_LOGIC_0 ) {
    value = 0;
   }
   else if (t > 0 && CLK.event() && CLK == SC_LOGIC_1) {
    value++;
	if (value == 10) value = 0;
   }   

   sc_lv<4> sclv_value(value);
   QA = sclv_value[0];
   QB = sclv_value[1];
   QC = sclv_value[2];
   QD = sclv_value[3];
  }
  
  SC_CTOR(counter): MON("MON")
  {
    value = 0;
    SC_METHOD(proc);
    sensitive << CLK.value_changed() << CLEAR;
    MON << QA << QB << QC << QD;
  }
};
#endif

