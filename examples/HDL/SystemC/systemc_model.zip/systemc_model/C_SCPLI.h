#ifndef C_SCPLIH
#define C_SCPLIH

#include "dll_header.h"
#include "systemc.h"

#define N_MAX_PIN 256
#define N_PORTS 2

//#define DEBUG

struct t_ddr_change {
	int idx, dir;
	wchar_t name[16];
};

__EXPORT_TYPE void sc_pli_connect();
__EXPORT_TYPE void sc_pli_set_node_changed(bool a);
__EXPORT_TYPE bool sc_pli_get_node_changed();
__EXPORT_TYPE int sc_pli_get_version();
__EXPORT_TYPE void sc_pli_set_analysis_mode(int a);

__EXPORT_TYPE void NewSystemCSession(char*& session_handle);
__EXPORT_TYPE void FreeSystemCSession(char* session_handle);

__EXPORT_TYPE int sc_pli_newdesign( int argc, char* argv[] );
__EXPORT_TYPE void sc_pli_run(double duration, int unit);
__EXPORT_TYPE void sc_pli_collect_interface_ports();
__EXPORT_TYPE int sc_pli_get_interface_port_count();
__EXPORT_TYPE double sc_pli_get_simulation_time();
__EXPORT_TYPE double sc_pli_get_next_event_time();
__EXPORT_TYPE bool sc_pli_init_mixed_nodes(void* pMixedNodes, void* pMacroPorts, int nMixedNodeCount, int nMacroPortsCount, int nGraphNumbers, char*& msg);
__EXPORT_TYPE void sc_pli_init_types(void* pMacroPorts, char* pMacroTypes, int nMacroPortsCount);
__EXPORT_TYPE void sc_pli_free();
__EXPORT_TYPE void sc_pli_finally();
__EXPORT_TYPE int sc_pli_get_digital_node_value(int dig_node, int& typ);
__EXPORT_TYPE double sc_pli_get_digital_node_value_real(int dig_node);
__EXPORT_TYPE void sc_pli_ad_interface(int dig_node, int val);
__EXPORT_TYPE void sc_pli_ad_interface_real(int dig_node, double val);

__EXPORT_TYPE void sc_pli_mcu_set_data(char* fn, double freq);
__EXPORT_TYPE int sc_pli_mcu_get_ddr_change_count();
__EXPORT_TYPE void sc_pli_mcu_get_ddr_change_info(int i, wchar_t*& sPinMain, int& iPinIndex, int& direction);
__EXPORT_TYPE void sc_pli_mcu_clear_ddr_changes();
__EXPORT_TYPE bool sc_pli_mcu_is_portpin(wchar_t* pin_name, wchar_t*& sPort, int& iPortIndex);
__EXPORT_TYPE void sc_pli_mcu_get_info(unsigned int& ram_begin_, unsigned int& ram_end_, unsigned int& flash_size_);
__EXPORT_TYPE void sc_pli_mcu_get_debugger_data(unsigned int& a);

__EXPORT_TYPE int sc_pli_get_flags(void);
__EXPORT_TYPE void* sc_pli_get_node_value(int idx);



char* find_interface_node(char* name);
void sc_pli_mcu_clear_changes();
void Dbg_SetCurrentPC(unsigned int a);
void traverse_objects();
void init_interface_ports(int a, char** ports);
void add_interface_port(sc_object* obj, bool f, int& c);

extern char hex_file_name[1024];
extern char debug_file_name[512];
extern double mcu_freq;
extern int iChangedPinCount, iChangedPinIndex[N_MAX_PIN], bChangedPinLevel[N_MAX_PIN], iDDRChangeCount;
extern t_ddr_change ddr_changes[256];
extern const wchar_t* PortDesignators[N_PORTS];

#endif


