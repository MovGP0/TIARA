#ifndef half_addH
#define half_addH

#include "monitor.h"

SC_MODULE(half_add)
{
  sc_in<sc_logic> A, B;
  sc_out<sc_logic> S, C;
  
  monitor MON;

  void proc() 
  { 
   S = A ^ B;
   C = A & B;
  }
  
  SC_CTOR(half_add): MON("MON")
  {
    SC_METHOD(proc);
    sensitive << A << B;
    MON << S << C;
  }
};
#endif

