#include "stdafx.h"
#include "PicDevices.h"
#include "string_util.h"
#include <string.h>
#include <stdlib.h>

bool PicOpcodeList::PushOpcode(char* str_command, char* str_argument, char* str_opcode, int opcode_id)
{
     if ( iCurrentSize >= iAllocation ) return false;

     StrUpperCase(str_opcode, strOpcode[iCurrentSize]);
     StrUpperCase(str_argument, strArgument[iCurrentSize]);
     StrUpperCase(str_command, strCommand[iCurrentSize]);

     iOpcodeID[iCurrentSize]  = opcode_id;

     if ( opcode_id >= 0 && opcode_id < 256 ) iOpcodeIDToEntry[opcode_id] = iCurrentSize;

     iCurrentSize++;
     return true;
}

long PicOpcodeList::GetMatchedOpcode(char* s_opcode, int& i_opcode_id, int& i_param_count, int* i_params )
{
     char* s;
     char c;
     int i, j, L, L0, Li, LAi;

     _try {
      s = strdup(s_opcode);
      L = strlen(s);
      if ( L == 0 ) return 0;

      L0 = strlen(strOpcode[0]);
      if ( L > L0 ) StrDelete(s, 1, L - L0);
      if ( L < L0 )
      {
           s = (char*)realloc(s, L0);
           for ( i = 0; i < L0 - L; i++ ) s[i] = '0';
           strcpy(s+L0-L, s);
      }

      for ( i = 0; i < iCurrentSize; i++ )
      {
            Li = strlen(strOpcode[i]);
            for ( j = 0; j < Li; j++ )
            {
                  c = strOpcode[i][j];
                  if ( c == '0' || c == '1' );
                  else continue;

                  if ( c != s[j] )break;
            }
            if ( j >= Li )break;
      }
      if ( i >= iCurrentSize )return -1;

      i_param_count = 0;

      LAi = strlen(strArgument[i]);
      for ( j = 0; j < LAi; j++ )
      {
            c = strArgument[i][j];
            if ( c == '_' )continue;
            i_params[i_param_count] = 0;

            Li = strlen(strOpcode[i]);
            for ( int l = 0; l < Li; l++ )
            {
                 if ( strOpcode[i][l] != c )continue;
                 i_params[i_param_count] = i_params[i_param_count]*2;
                 if ( s[l] == '1' )i_params[i_param_count]++;
            }
            i_param_count++;
      }

      i_opcode_id = iOpcodeID[i];
      return 1;
     }
     __finally {
      free(s);
     }
}

