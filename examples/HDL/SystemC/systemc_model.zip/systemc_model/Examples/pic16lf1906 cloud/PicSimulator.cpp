#include "stdafx.h"
#include "PicSimulator.h"
 
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>

#include "string_util.h"
#include "pic.h"


PicSimulator::PicSimulator()
{
    iFlashOpcodeID     = NULL;
    iFlashOpcodeParam1 = NULL;
    iFlashOpcodeParam2 = NULL;
    iFlashOpcodeParam3 = NULL;

    fPinVolt           = new double[PIC_DEVICE_MAXIMUM_PIN_COUNT];


    iPcStackDepth = 8;

    portDriver.SetParent(this,&iLogType,&iLogLevel);
}

void PicSimulator::Load14Bit35InstructionSet()
{
    opcode_list.Reset();
    opcode_list.PushOpcode("ADDWF",	    "FD",	"000111dfffffff",	PIC_OPCODE_ADDWF );
    opcode_list.PushOpcode("ANDWF",	    "FD",	"000101dfffffff",	PIC_OPCODE_ANDWF );
    opcode_list.PushOpcode("CLRF",	    "F",	"0000011fffffff",	PIC_OPCODE_CLRF );
    opcode_list.PushOpcode("CLRW",	    "_",	"0000010xxxxxxx",	PIC_OPCODE_CLRW );
    opcode_list.PushOpcode("COMF",	    "FD",	"001001dfffffff",	PIC_OPCODE_COMF );
    opcode_list.PushOpcode("DECF",	    "FD",	"000011dfffffff",	PIC_OPCODE_DECF );
    opcode_list.PushOpcode("DECFSZ",    "FD",	"001011dfffffff",	PIC_OPCODE_DECFSZ );
    opcode_list.PushOpcode("INCF",	    "FD",	"001010dfffffff",	PIC_OPCODE_INCF );
    opcode_list.PushOpcode("INCFSZ",    "FD",	"001111dfffffff",	PIC_OPCODE_INCFSZ );
    opcode_list.PushOpcode("IORWF",	    "FD",	"000100dfffffff",	PIC_OPCODE_IORWF );
    opcode_list.PushOpcode("MOVF",	    "FD",	"001000dfffffff",	PIC_OPCODE_MOVF );
    opcode_list.PushOpcode("MOVWF",	    "F",	"0000001fffffff",	PIC_OPCODE_MOVWF);
	
    // for some new PIC16: PIC16LF1906, should be before NOP
    //if (iDeviceRef == 30326) {
	 opcode_list.PushOpcode("MOVLB",     "K",    "000000001kkkkk",   PIC_OPCODE_MOVLB );
     opcode_list.PushOpcode("LSLF",	    "FD",    "110101dfffffff",	 PIC_OPCODE_LSLF );
     opcode_list.PushOpcode("LSRF",	    "FD",  	 "110110dfffffff",	 PIC_OPCODE_LSRF );
     opcode_list.PushOpcode("MOVLP",    "K",     "1100011kkkkkkk",	 PIC_OPCODE_MOVLP );
	 opcode_list.PushOpcode("ADDWFC",   "FD",    "111101dfffffff",	 PIC_OPCODE_ADDWFC );
	 opcode_list.PushOpcode("SUBWFB",   "FD",    "111011dfffffff",	 PIC_OPCODE_SUBWFB );
    //}
	
    opcode_list.PushOpcode("NOP",	    "_",	"0000000xx00000",	PIC_OPCODE_NOP );
    opcode_list.PushOpcode("RLF",	    "FD",	"001101dfffffff",	PIC_OPCODE_RLF );
    opcode_list.PushOpcode("RRF",	    "FD",	"001100dfffffff",	PIC_OPCODE_RRF );
    opcode_list.PushOpcode("SUBWF",	    "FD",	"000010dfffffff",	PIC_OPCODE_SUBWF );
    opcode_list.PushOpcode("SWAPF",	    "FD",	"001110dfffffff",	PIC_OPCODE_SWAPF );
    opcode_list.PushOpcode("XORWF",	    "FD",	"000110dfffffff",	PIC_OPCODE_XORWF );
    opcode_list.PushOpcode("BCF",	    "FB",	"0100bbbfffffff",	PIC_OPCODE_BCF );
    opcode_list.PushOpcode("BSF",	    "FB",	"0101bbbfffffff",	PIC_OPCODE_BSF );
    opcode_list.PushOpcode("BTFSC",	    "FB",	"0110bbbfffffff",	PIC_OPCODE_BTFSC );
    opcode_list.PushOpcode("BTFSS",	    "FB",	"0111bbbfffffff",	PIC_OPCODE_BTFSS );
    opcode_list.PushOpcode("ADDLW",	    "K",	"11111xkkkkkkkk",	PIC_OPCODE_ADDLW );
    opcode_list.PushOpcode("ANDLW",	    "K",	"111001kkkkkkkk",	PIC_OPCODE_ANDLW );
    opcode_list.PushOpcode("CALL",	    "K",	"100kkkkkkkkkkk",	PIC_OPCODE_CALL );
    opcode_list.PushOpcode("CLRWDT",	"_",	"00000001100100",   PIC_OPCODE_CLRWDT );
    opcode_list.PushOpcode("GOTO",	    "K",	"101kkkkkkkkkkk",	PIC_OPCODE_GOTO);
    opcode_list.PushOpcode("IORLW",	    "K",	"111000kkkkkkkk",	PIC_OPCODE_IORLW );
    opcode_list.PushOpcode("MOVLW",	    "K",	"1100xxkkkkkkkk",	PIC_OPCODE_MOVLW );
    opcode_list.PushOpcode("RETFIE",	"_",	"00000000001001",   PIC_OPCODE_RETFIE );
    opcode_list.PushOpcode("RETLW",	    "K",	"1101xxkkkkkkkk",	PIC_OPCODE_RETLW );
	opcode_list.PushOpcode("RETURN",	"_",	"00000000001000",	PIC_OPCODE_RETURN );
    opcode_list.PushOpcode("SLEEP",	    "_",	"00000001100011",	PIC_OPCODE_SLEEP );
    opcode_list.PushOpcode("SUBLW",	    "K",	"11110xkkkkkkkk",	PIC_OPCODE_SUBLW );
	opcode_list.PushOpcode("XORLW",	    "K",	"111010kkkkkkkk",	PIC_OPCODE_XORLW );

	opcode_list.PushOpcode("OPTION",    "-",    "00000001100010", PIC_OPCODE_OPTION );
	opcode_list.PushOpcode("TRIS",      "F",    "00000001100fff", PIC_OPCODE_TRIS );

};

void PicSimulator::CreateDevice(long instruction_length_in_bit,long flash_size,long eeprom_size,long data_mem_size,double frequency_mega_hertz,double vcc_min,double vcc_max)
{
	iInstructionLengthInBit = instruction_length_in_bit;

    Load14Bit35InstructionSet();
    iPcStackDepth = 8;

    iFlashSize = flash_size;
    iEepromSize = eeprom_size;
    iDataMemSize= data_mem_size;

    fFrequencyMHZ = frequency_mega_hertz;
    fVccMIN = vcc_min;
    fVccMax = vcc_max;

    iFlashCode = new unsigned int [iFlashSize+1];
    iFlashOpcodeID = new int[iFlashSize+1];
    iFlashOpcodeParam1 = new int[iFlashSize+1];
    iFlashOpcodeParam2 = new int[iFlashSize+1];
    iFlashOpcodeParam3 = new int[iFlashSize+1];

    iBsrAddress = 0x08;
    iWregAddress = 9;
    iCommonRAMStart = 0x70; iCommonRAMEnd = 0x7F;
    iStatusAddress = 0x03;
    iPclAddress = 0x02;
    iPclathAddress = 0x0A;
    iOptionAddress = 0x95;
    if ( iInstructionLengthInBit == 12 )iOptionAddress = 0x100; // virtual
    iIntconAddress = 0x0B;
    iFsrAddress = 0x04;
    //iPie1Address  = SfrAddressFromName("PIE1"); // 0x8C
    //iPie2Address  = SfrAddressFromName("PIE2"); // 0x8D
    //iPir1Address  = SfrAddressFromName("PIR1"); // 0x0C;
    //iPir2Address  = SfrAddressFromName("PIR2"); // 0x0D;
    iPconAddress  = 0x96;

    //for ( int i = 0; i < PIC_DEVICE_MEMORY_SIZE; i++ )bValidMemory[i] = false;
    //for ( int i = 0; i < GetSfrCount(); i++ )bValidMemory[SfrAddressFromIndex(i)] = true;

    // ----- TRANSFORMATION INITIALIZATION -------------------------------------

    if ( iOptionAddress < 0x100 )iMemoryTransform[iOptionAddress + 0x100] = iOptionAddress;

    iMemoryTransform[iStatusAddress + 0x180] = iMemoryTransform[iStatusAddress + 0x100] = iMemoryTransform[iStatusAddress + 0x80] = iStatusAddress;
    iMemoryTransform[iPclAddress    + 0x180] = iMemoryTransform[iPclAddress    + 0x100] = iMemoryTransform[iPclAddress    + 0x80] = iPclAddress;
    iMemoryTransform[iPclathAddress + 0x180] = iMemoryTransform[iPclathAddress + 0x100] = iMemoryTransform[iPclathAddress + 0x80] = iPclathAddress;
    iMemoryTransform[iIntconAddress + 0x180] = iMemoryTransform[iIntconAddress + 0x100] = iMemoryTransform[iIntconAddress + 0x80] = iIntconAddress;
    iMemoryTransform[iFsrAddress    + 0x180] = iMemoryTransform[iFsrAddress    + 0x100] = iMemoryTransform[iFsrAddress    + 0x80] = iFsrAddress;

    // -------------------------------------------------------------------------

    if ( iFlashSize > 4096 )iPcMaximum = 0x1FFF;
    else if ( iFlashSize > 2048 )iPcMaximum = 0x0FFF;
    else if ( iFlashSize > 1024 )iPcMaximum = 0x7FF;
    else if ( iFlashSize > 512  )iPcMaximum = 0x3FF;
    else if ( iFlashSize > 256  )iPcMaximum = 0x1FF;
    else iPcMaximum = 0xFF;

    char _s[256], buf[32];

    iAvccPin = PinIndexFromName("AVCC");
    iAgndPin = PinIndexFromName("AGND");
    iVrefPin = PinIndexFromName("VREF");
    if ( iVrefPin < 0 )iVrefPin = PinIndexFromName("VREF+");

    // ------   INITIALIZE PORT DRIVER   -----
    // ---------------------------------------

    int port_to_pin [ PIC_DEVICE_MAXIMUM_PORT_COUNT * 8 ];
    int port_count = 0;
	for ( int i = 0; i < PIC_DEVICE_MAXIMUM_PORT_COUNT * 8; i++ )port_to_pin[i] = -1;
    bool bGPPin = false;

    for ( int i = 0; i < PIC_DEVICE_MAXIMUM_PORT_COUNT; i++ )
    {
          for ( int j = 0; j < 8; j++ )
          {
                strcpy(_s, "R");
                buf[0] = (char)('A' + i); buf[1] = '\0'; strcat(_s, buf);
                buf[0] = '0'+j; buf[1] = '\0'; strcat(_s, buf);

                port_to_pin [ i * 8 + j ] = PinIndexFromName ( _s );
                if ( port_to_pin [ i * 8 + j ] >= 0 )port_count = i + 1;
          }
    }

    if ( port_count == 0 )
    {
         for ( int j = 0; j < 8; j++ )
         {
                strcpy(_s, "GP");
                buf[0] = '0'+j; buf[1] = '\0'; strcat(_s, buf);

                port_to_pin [ 0 * 8 + j ] = PinIndexFromName ( _s );
                if ( port_to_pin [ 0 * 8 + j ] >= 0 )port_count = 0 + 1;
         }
         if ( port_count > 0 )bGPPin = true;
    }

    if ( iInstructionLengthInBit == 14 )portDriver.Create(0x0C,0x8C,port_count,port_to_pin);
    /*else if ( iInstructionLengthInBit == 12 )
    {
         if ( bGPPin == true )
              portDriver.Create(0x06,0x106,port_count,port_to_pin); // 0x106 is virtual
         else portDriver.Create(0x05,0x105,port_count,port_to_pin); // 0x105 is virtual
    }
*/
}

bool PicSimulator::SetDevice()
{
    for ( int i = 0; i < PIC_DEVICE_MEMORY_SIZE; i++ )
    {
          bValidMemory[i] = true;
          bValidSfr[i]   = true;
          iMemoryTransform[i] = i;
    }
    iSramBlockCount = 0;

    SetPinLayout("[CLK][RA0][RA1][RA2][RA3][RA4][RA5][VSS][RA7][RA6][RC0][RC1][RC2][RC3][RB7][RB6][RB5][RB4][RB3][RB2][RB1][RB0][VDD][RC7][RC6][RC5][RC4]"); //28 pin PDIP
	CreateDevice(14,8192,64,96,20,1.8,5.0);
	AddSramBlock(0x20,0x7F);AddSramBlock(0xA0,0xFF);
	AddTransformBlock(0x120,0x17F,0x20);AddTransformBlock(0x1A0,0x1FF,0xA0);
	
    return true;	
}

int PicSimulator::Me_GetCurrentInstructionNecessaryCycle()
{
    if ( bSleeping )return 1;

    if ( iCurrentPC >= iFlashSize )iCurrentPC = 0;

    int opcode_id     = iFlashOpcodeID[iCurrentPC];
    int opcode_param1 = iFlashOpcodeParam1[iCurrentPC];
    int opcode_param2 = iFlashOpcodeParam2[iCurrentPC];
    int opcode_param3 = iFlashOpcodeParam3[iCurrentPC];

    if ( opcode_id == PIC_OPCODE_CALL )	return 2;
    else if ( opcode_id == PIC_OPCODE_GOTO )return 2;
    else if ( opcode_id == PIC_OPCODE_RETFIE )return 2;
    else if ( opcode_id == PIC_OPCODE_RETLW )return 2;
    else if ( opcode_id == PIC_OPCODE_RETURN )return 2;
    else if ( opcode_id == PIC_OPCODE_DECFSZ  && GetMemValue ( opcode_param1 ) == 1 )return 2;
    else if ( opcode_id == PIC_OPCODE_INCFSZ  && GetMemValue ( opcode_param1 ) == 0xFF )return 2;
    else if ( opcode_id == PIC_OPCODE_BTFSC  && ( GetMemValue ( opcode_param1 ) & ( 1 << opcode_param2 ) ) == 0 )return 2;
    else if ( opcode_id == PIC_OPCODE_BTFSS  && ( GetMemValue ( opcode_param1 ) & ( 1 << opcode_param2 ) ) != 0 )return 2;

    return 1;
}

using namespace std;

void PicSimulator::LoadHEXFile(char *fn)
{
    ifstream in_stream;
    in_stream.open(fn);
	string line;
    int i = 0;
    char *p, buf[256], *str_temp;
    int ln_pos, ln_data_count;
    unsigned int ln_addr, ln_data;
    int proc_type = -1;
    int bit_per_word = 16;
	int *i_params;
    int i_param_count,i_consumed,i_opcode_id;


    proc_type = MCU_SIMULATOR_TYPE_PIC;
    bit_per_word = 16; // pic
    i_params = new int[6];
    for ( i = 0; i < 6; i++ ) i_params[i] = 0;

    while (!in_stream.eof())
    {
 	 getline( in_stream, line );

     str_temp = (char*)line.c_str(); // str_temp is read-only
     if (str_temp[0] != ':') return;

     ln_pos = 2;
     ln_data_count = hexToInt(StrSubString(str_temp, buf, ln_pos, 2));

     if ( bit_per_word == 32 )ln_data_count /= 4;
     else if ( bit_per_word != 8 )ln_data_count /= 2; //series 51
     ln_pos += 2;

     ln_addr = hexToInt(StrSubString(str_temp,buf,ln_pos,4));

     if ( bit_per_word == 32 )ln_addr /= 4;
     else if ( bit_per_word != 8 )ln_addr /= 2;
     ln_pos += 4;

     ln_data = hexToInt(StrSubString(str_temp,buf,ln_pos,2));
     ln_pos += 2;

     if (ln_data == 0)
     {
         for (int j = 0; j < ln_data_count; j++, ln_addr++)
         {
           ln_data = hexToInt(StrSubString(str_temp,buf,ln_pos,2))+hexToInt(StrSubString(str_temp,buf,ln_pos+2,2))*256;
           ln_pos += 4;

           //ln_addr, ln_data available
           decimal_to_binary(buf, ln_data, bit_per_word);
		   if ( opcode_list.GetMatchedOpcode(buf,i_opcode_id,i_param_count,i_params) <= 0 ) {
			//throw Exception("PIC16 simulator: invalid opcode");
		   }

		   iFlashOpcodeID[ln_addr] = i_opcode_id;
		   iFlashOpcodeParam1[ln_addr] = i_params[0];
		   iFlashOpcodeParam2[ln_addr] = i_params[1];
		   iFlashOpcodeParam3[ln_addr] = i_params[2];
         }
      }
     i++;
    }
	
    in_stream.close();
    delete [] i_params;
}

bool PicSimulator::StartSimulation()
{
    SetDevice();
	
    LoadHEXFile(hex_file_name);
	
    for ( int i = 0 ; i < PIC_DEVICE_MEMORY_SIZE; i++ )cMemory[i]= 0;

    iCurrentPC = 0;
	bSleeping = false;
    //Dbg_SetCurrentPC(iCurrentPC);

    //listener->OnWriteSfr ( iPclathAddress , iCurrentPC / 256 );
    //listener->OnWriteSfr ( iPclAddress , iCurrentPC % 256 );

    for ( int i = 0; i < iPinCount; i++ ) //Set all pin as input state and true
    {
          cPinStatus[i] = 1;
          cPinData[i]   = /*1*/ 0;        // Attila PINDEFAULTZERO: 2009/07/26
          fPinVolt[i]   = /*5.0*/ 0.0;    // Attila PINDEFAULTZERO: 2009/07/26
    }

    portDriver.Reset(RESET_POWER_ON);

    SetMemValue(iStatusAddress,0x18);
    SetMemValue(iOptionAddress,0xFF);
    if ( iPconAddress >= 0 )SetMemValue(iPconAddress,1);

    cWValue = 0;
    //listener->OnWriteRegister(0,cWValue);

    fPinVolt [ iVccPin ] = 5.0;
    fPinVolt [ iGndPin ] = 0.0;
    if ( iResetPin >= 0 )fPinVolt [ iResetPin]= /*5.0*/ 0.0;   //Attila PINDEFAULTZERO

    cPinData [ iVccPin ] = 1;
    cPinData [ iGndPin ] = 0;
    if ( iResetPin >= 0 )cPinData [ iResetPin]= /*5*/ 0;   //Attila PINDEFAULTZERO

    fPrevVccVoltage = 5;

    bInterrupt = false;
    iCurrentInstructionNecessaryCycle = Me_GetCurrentInstructionNecessaryCycle();
    return true;
}

void PicSimulator::ExecuteCurrentInstructionOnly()
{
    if ( iVccPin >= 0 && fPinVolt[iVccPin]-fPinVolt[iGndPin] < 0.8 )return;	  // Attila GNDFIX: 2009/07/26
    if ( bSleeping )return;

    if ( iCurrentPC >= iFlashSize )iCurrentPC = 0;

    //MCUTEST
    //if (iCurrentPC == 0x002D)
    // int a=1;

    int opcode_id     = iFlashOpcodeID[iCurrentPC];
    int opcode_param1 = iFlashOpcodeParam1[iCurrentPC];
    int opcode_param2 = iFlashOpcodeParam2[iCurrentPC];
    int opcode_param3 = iFlashOpcodeParam3[iCurrentPC];

    int  temp;

    t_pic_opcode_id     pic_opcode_id = (t_pic_opcode_id)opcode_id;
	
	
    int prev_w = cWValue;

    if ( opcode_id == PIC_OPCODE_ADDLW )
    {
         temp = cWValue + opcode_param1;
         SetDigitCarryFlag ( ( cWValue & 0x0F ) + ( opcode_param1 & 0x0F ) > 0x0F );

         cWValue = ( temp & 0xFF );

         SetZeroFlag  ( cWValue == 0 );
         SetCarryFlag ( temp > 0xFF );
    }
    else if ( opcode_id == PIC_OPCODE_ADDWF )
    {
         temp = cWValue + GetMemValue(opcode_param1);
         SetDigitCarryFlag ( ( cWValue & 0x0F ) + ( GetMemValue(opcode_param1) & 0x0F ) > 0x0F );

         if ( opcode_param2 == 0 )cWValue = ( temp & 0xFF );
         else SetMemValue ( opcode_param1, ( temp & 0xFF ) );

         SetZeroFlag ( temp == 0 );
         SetCarryFlag( temp > 0xFF );
    }
	else if ( opcode_id == PIC_OPCODE_ADDWFC )
	{
		 temp = cWValue + GetMemValue(opcode_param1);
		 SetDigitCarryFlag ( ( cWValue & 0x0F ) + ( GetMemValue(opcode_param1) & 0x0F ) > 0x0F );

		 temp += GetCarryFlag();

		 if ( opcode_param2 == 0 )cWValue = ( temp & 0xFF );
		 else SetMemValue ( opcode_param1, ( temp & 0xFF ) );

		 SetCarryFlag( temp >= 0x100 );

		 temp &= 0xFF;                                                          // Float fix

		 SetZeroFlag ( temp == 0 );
	}
    else if ( opcode_id == PIC_OPCODE_ANDLW )
    {
         cWValue = ( cWValue & opcode_param1 );
         SetZeroFlag ( cWValue == 0 );
    }
    else if ( opcode_id == PIC_OPCODE_ANDWF )
    {
         temp = ( cWValue & GetMemValue ( opcode_param1 ) );
         if ( opcode_param2 == 0 )cWValue  = temp;
         else SetMemValue ( opcode_param1, temp );

         SetZeroFlag ( temp == 0 );
    }
    else if ( opcode_id == PIC_OPCODE_BCF )
    {
         temp = ( GetMemValue ( opcode_param1 ) & ( 0xFF - ( 1 << opcode_param2 ) ) );
         SetMemValue ( opcode_param1, temp );
    }
    else if ( opcode_id == PIC_OPCODE_BSF )
    {
         temp = ( GetMemValue ( opcode_param1 ) | ( 1 << opcode_param2 ) );
         SetMemValue ( opcode_param1, temp );
    }
    else if ( opcode_id == PIC_OPCODE_BTFSC )
    {
         if ( ( GetMemValue ( opcode_param1 ) & ( 1 << opcode_param2 ) ) == 0 )iCurrentPC++;
    }
    else if ( opcode_id == PIC_OPCODE_BTFSS )
    {
         if ( GetMemValue ( opcode_param1 ) & ( 1 << opcode_param2 ) )iCurrentPC++;
    }
    else if ( opcode_id == PIC_OPCODE_CALL )
    {
         for ( int i = iPcStackDepth - 1; i > 0 ; i-- )iPcStack [ i ] = iPcStack [ i - 1 ];
         iPcStack [ 0 ] = iCurrentPC + 1;

         iCurrentPC = ( ( GetMemValue ( iPclathAddress ) & 0x18 ) / 0x08 ) * 2048 + opcode_param1;
         iCurrentPC--;  // because, at last of this if else ladder, iCurrentPC++
    }
    else if ( opcode_id == PIC_OPCODE_CLRF )
    {
         if ( opcode_param1 == iStatusAddress )
              SetMemValue ( opcode_param1, ( cMemory [ iStatusAddress ] & 0x1F ) );
         else SetMemValue ( opcode_param1, 0 );

         SetZeroFlag ( true );
    }
    else if ( opcode_id == PIC_OPCODE_CLRW )
    {
         cWValue = 0;
         SetZeroFlag ( true );
    }
    else if ( opcode_id == PIC_OPCODE_CLRWDT )
    {
         //watchdogDriver.ClearCount();
         if ( cMemory [ iOptionAddress ] & 0x08 ) // PSA = 1, SO SET FOR WATCHDOG AND SO CLEAR IT
              cMemory [ iOptionAddress ] &= ( 0xFF - 0x07 );

         cMemory [ iStatusAddress ] |= 0x18; // _T0 <= 1 AND _PD <= 1

         //listener->OnWriteSfr(iOptionAddress,cMemory[iOptionAddress]);
         //listener->OnWriteSfr(iStatusAddress,cMemory[iStatusAddress]);
    }
    else if ( opcode_id == PIC_OPCODE_COMF )
    {
         temp = 0xFF - GetMemValue ( opcode_param1 );
         if ( opcode_param2 == 0 )cWValue = temp;
         else SetMemValue ( opcode_param1, temp );

         SetZeroFlag ( temp == 0 );
    }
    else if ( opcode_id == PIC_OPCODE_DECF )
    {
         temp = GetMemValue ( opcode_param1 ) - 1;
         if ( temp < 0 )temp = 0xFF;

         if ( opcode_param2 == 0 )cWValue = temp;
         else SetMemValue ( opcode_param1,temp );

         SetZeroFlag ( temp == 0 );
    }
    else if ( opcode_id == PIC_OPCODE_DECFSZ )
    {
         temp = GetMemValue ( opcode_param1 ) - 1;
         if ( temp < 0 )temp = 0xFF;

         if ( opcode_param2 == 0 )cWValue = temp;
         else SetMemValue ( opcode_param1, temp );

         if ( temp == 0 )
         {
              SetZeroFlag ( true );
              iCurrentPC++;
         }
         else SetZeroFlag ( false );
    }
    else if ( opcode_id == PIC_OPCODE_GOTO )
    {
         iCurrentPC = ( ( GetMemValue( iPclathAddress ) & 0x18 ) / 0x08 ) * 2048 + opcode_param1;
         iCurrentPC--; //BECAUSE AT LAST OF THIS SEGMENT, iCurrentPC++
    }
    else if ( opcode_id == PIC_OPCODE_INCF )
    {
         temp = GetMemValue ( opcode_param1 ) + 1;
         temp = temp & 0xFF;

         if ( opcode_param2 == 0 )cWValue = temp;
         else SetMemValue ( opcode_param1, temp );

         SetZeroFlag ( temp == 0 );
    }
    else if ( opcode_id == PIC_OPCODE_INCFSZ )
    {
         temp = GetMemValue ( opcode_param1 ) + 1;
         temp = temp & 0xFF;

         if ( opcode_param2 == 0 )cWValue = temp;
         else SetMemValue ( opcode_param1, temp );

         SetZeroFlag ( temp == 0 );
         if ( temp == 0 )iCurrentPC++;
    }
    else if ( opcode_id == PIC_OPCODE_IORLW )
    {
         cWValue = opcode_param1 | cWValue;
         SetZeroFlag ( cWValue == 0 );
    }
    else if ( opcode_id == PIC_OPCODE_IORWF )
    {
         temp = GetMemValue ( opcode_param1 ) | cWValue;

         if ( opcode_param2 == 0 )cWValue = temp;
         else SetMemValue ( opcode_param1,temp );

         SetZeroFlag ( temp == 0 );
    }
    else if ( opcode_id == PIC_OPCODE_MOVF )
    {
         temp = GetMemValue ( opcode_param1 );
         if ( opcode_param2 == 0 )cWValue = temp;
         else SetMemValue ( opcode_param1, temp );

         SetZeroFlag ( temp == 0 );
    }
    else if ( opcode_id == PIC_OPCODE_MOVLW )
    {
         cWValue = opcode_param1;
    }
    else if ( opcode_id == PIC_OPCODE_MOVWF )
    {
         SetMemValue ( opcode_param1,cWValue );
    }
    else if ( opcode_id ==  PIC_OPCODE_NOP  );
    else if ( opcode_id == PIC_OPCODE_RETFIE )
    {
         iCurrentPC = iPcStack[0];
         for ( int i = 0; i < iPcStackDepth - 1; i++ )iPcStack [ i ] = iPcStack [ i + 1 ];
         iCurrentPC--;   // BECAUSE AT LAST OF THIS SEGMENT, iCurrentPC++

         cMemory [ iIntconAddress ] |= 0x80;  // Enable global interrupt
         //listener->OnWriteSfr(iIntconAddress,cMemory[iIntconAddress]);
    }
    else if ( opcode_id == PIC_OPCODE_RETLW )
    {
         iCurrentPC = iPcStack[0];
         for ( int i = 0; i < iPcStackDepth - 1; i++ )iPcStack [ i ] = iPcStack [ i + 1 ];
         iCurrentPC--;    // BECAUSE, AT LAST OF THIS IF ELSE, iCurrentPC++

         cWValue = opcode_param1;
    }
    else if ( opcode_id == PIC_OPCODE_RETURN )
    {
         iCurrentPC = iPcStack[0];
         for ( int i = 0; i < iPcStackDepth - 1; i++ )iPcStack [ i ] = iPcStack [ i + 1 ];
         iCurrentPC--;    // BECAUSE, AT LAST OF THIS IF ELSE, iCurrentPC++
    }
    else if ( opcode_id == PIC_OPCODE_RLF )
    {
         bool b_carry = GetCarryFlag();

         if ( GetMemValue ( opcode_param1 ) & 0x80 )SetCarryFlag ( true );
         else SetCarryFlag ( false );

         temp = ( ( GetMemValue ( opcode_param1 ) * 2 ) & 0xFE );
         if ( b_carry )temp++;

         if ( opcode_param2 == 1 )SetMemValue ( opcode_param1, temp );
         else cWValue = temp;
    }
    else if ( opcode_id == PIC_OPCODE_RRF )
    {
         bool b_carry = GetCarryFlag();

         if ( GetMemValue ( opcode_param1 ) & 0x01 )SetCarryFlag ( true );
         else SetCarryFlag ( false );

         temp = GetMemValue ( opcode_param1 ) / 2;
         if ( b_carry )temp += 128;

         if ( opcode_param2 == 1 )SetMemValue ( opcode_param1, temp );
         else cWValue = temp;
    }
    else if ( opcode_id == PIC_OPCODE_SLEEP )
    {
         bSleeping = true;
         //watchdogDriver.ClearCount();

         if ( ( cMemory [ iOptionAddress ] & 0x08 ) == 0x08 ) // PSA = 1, SO SET FOR THE WATCHDOG
                cMemory [ iOptionAddress ] &= ( 0xFF - 0x07 );

         cMemory [ iStatusAddress ] |= 0x10; // _TO <= 1
         cMemory [ iStatusAddress ] &= ( 0xFF - 0x80 ); // _PD <= 0

         //listener->OnWriteSfr(iOptionAddress,cMemory[iOptionAddress]);
         //listener->OnWriteSfr(iStatusAddress,cMemory[iStatusAddress]);

         iCurrentPC--; // ACCORDING TO SLEEP, iCurrentPC should not increment, but at last, there is iCurrentPC++
    }
    else if ( opcode_id == PIC_OPCODE_SUBLW )
    {
         temp = opcode_param1 - cWValue;
         SetDigitCarryFlag ( ( opcode_param1 & 0x0F ) >= ( cWValue & 0x0F ) );

         SetZeroFlag ( temp == 0 );
         SetCarryFlag( temp >= 0 );

         if ( temp < 0 )temp += 0x100; // 2's complement
         cWValue = temp;
    }
    else if ( opcode_id == PIC_OPCODE_SUBWF )
    {
         temp = GetMemValue ( opcode_param1 ) - cWValue;
         SetDigitCarryFlag ( ( GetMemValue(opcode_param1) & 0x0F ) >= ( cWValue & 0x0F ) );

         SetZeroFlag ( temp == 0 );
         SetCarryFlag( temp >= 0 );

         if ( temp < 0 )temp += 0x100; // 2's complement

         if ( opcode_param2 == 1 )SetMemValue ( opcode_param1, temp );
         else cWValue = temp;
    }
	else if ( opcode_id == PIC_OPCODE_SUBWFB )
	{
		 temp = GetMemValue ( opcode_param1 ) - cWValue;
		 SetDigitCarryFlag ( ( GetMemValue(opcode_param1) & 0x0F ) >= ( cWValue & 0x0F ) );

		 SetZeroFlag ( temp == 0 );
		 SetCarryFlag( temp >= 0 );

         if ( !GetCarryFlag() )temp--;

		 if ( temp < 0 )temp += 0x100; // 2's complement

		 if ( opcode_param2 == 1 )SetMemValue ( opcode_param1, temp );
		 else cWValue = temp;
	}
    else if ( opcode_id == PIC_OPCODE_SWAPF )
    {
         temp = GetMemValue ( opcode_param1 );
         temp = ( temp & 0x0F ) * 16 + ( temp & 0xF0 ) / 16;

         if ( opcode_param2 == 1 )SetMemValue ( opcode_param1, temp );
         else cWValue = temp;
    }
    else if ( opcode_id == PIC_OPCODE_XORLW )
    {
         cWValue = ( ( cWValue & ( 0xFF - opcode_param1 ) ) | ( ( 0xFF - cWValue ) & opcode_param1 ) );
         SetZeroFlag ( cWValue == 0 );
    }
    else if ( opcode_id == PIC_OPCODE_XORWF )
    {
         temp = GetMemValue ( opcode_param1 );
         temp = ( ( temp & ( 0xFF - cWValue ) ) | (  ( 0xFF - temp ) & cWValue ) );

         if ( opcode_param2 == 1 )SetMemValue ( opcode_param1, temp );
         else cWValue = temp;

         SetZeroFlag ( temp == 0 );
    }
	else if ( opcode_id == PIC_OPCODE_TRIS ) // 33 && 35 INSTRUCTION SET
    {
		 if ( opcode_param1 == 5 || opcode_param1 == 6 || opcode_param1 == 7 )
		  if (iInstructionLengthInBit == 12)
			  SetMemValue ( 0x100 + opcode_param1 , cWValue );  //  virtual
		  else
			  SetMemValue ( 0x80 + opcode_param1 , cWValue );
	}
    else if ( opcode_id == PIC_OPCODE_OPTION ) // 33 INSTRUCTION SET.
    {
	  if (iInstructionLengthInBit == 12)
		 SetMemValue ( 0x100, cWValue );  // virtual
	  else
		 SetMemValue ( 0x81, cWValue );
	}

    // for some new PIC16: PIC16LF1906
    else if ( opcode_id == PIC_OPCODE_MOVLB )
    {
         temp = opcode_param1;
		 SetMemValue ( iBsrAddress, temp );
    }
    else if ( opcode_id == PIC_OPCODE_LSLF )
    {
         temp = GetMemValue( opcode_param1 );
         SetCarryFlag(temp & 0x80);

         temp *= 2;
         SetZeroFlag ( temp == 0 );

		 if ( opcode_param2 == 1 ) SetMemValue ( opcode_param1, temp );
         else cWValue = temp;
    }
    else if ( opcode_id == PIC_OPCODE_LSRF )
    {
         temp = GetMemValue( opcode_param1 );
         SetCarryFlag(temp & 0x1);

         temp /= 2;
         SetZeroFlag ( temp == 0 );

		 if ( opcode_param2 == 1 ) SetMemValue ( opcode_param1, temp );
         else cWValue = temp;
    }
    else if ( opcode_id == PIC_OPCODE_MOVLP )
    {
         temp = opcode_param1;
		 SetMemValue ( iPclathAddress, temp );
    }

    iCurrentPC++;

    bool is_interrupt = bInterrupt;
    //if ( bInterrupt )HandleInterrupt();

    if ( iCurrentPC > iPcMaximum )iCurrentPC = ( iCurrentPC & iPcMaximum );
    //cMemory [ iPclathAddress ] = iCurrentPC / 256;        //Commented on 2 March 09
    cMemory [ iPclAddress ] = ( iCurrentPC & 0xFF );

    iCurrentInstructionNecessaryCycle = Me_GetCurrentInstructionNecessaryCycle();

    if ( prev_w != cWValue )
    {
         cMemory[iWregAddress] = cWValue;
         //listener->OnWriteSfr(iWregAddress,cWValue);
         //listener->OnWriteRegister(0,cWValue);
    }


    #ifdef DEBUG
	char sCurrentPC[128];
	IntToHex(iCurrentPC, sCurrentPC);
	int ptemp[3];
	for (int i=0; i<3; i++) ptemp[i] = GetMemValue(0x0C+i, true);
	debug.open(debug_file_name, std::ofstream::out | std::ofstream::app);
	debug << "After ExecuteCurrentInstructionOnly: time: " << sc_get_curr_simcontext()->time_stamp().to_string();
	debug << ", current pc: 0x" << sCurrentPC;
	debug << ", PORTA: " << ptemp[0] << ", PORTB: " << ptemp[1] << ", PORTC: " << ptemp[2];
	debug << endl;
	debug.close();
    #endif

    //Dbg_SetCurrentPC(iCurrentPC);
	
    //if ( !is_interrupt )listener->OnChangePC ( iCurrentPC ); //because, HandleInterrupt calls listener->OnChangePC
    //listener->OnWriteSfr ( iPclathAddress,cMemory [ iPclathAddress ]); //Commented on 2 March 09
    //listener->OnWriteSfr ( iPclAddress,cMemory [ iPclAddress ]);
}

void PicSimulator::P_SetPinData(int pin_no, bool val, bool from_port_driver)
{
	int port_no, pin, i_val;
	
	if (pin_no < 0 || pin_no >= iPinCount)return;

	bool b_prev = cPinData[pin_no] & 0x01;

	if (val)cPinData[pin_no] |= 1;
	else cPinData[pin_no] &= (0xFF - 0x01);

    portDriver.GetPinNo(pin_no, port_no, pin);
	if (val) i_val = 1; else i_val = 0;
	((pic*)listener)->OnChangePinData(port_no, pin, i_val);

	//if ( b_prev != val && ( iLogType & SIMULATOR_LOG_PIN_OUT ) != 0 )listener->OnWriteLog(SIMULATOR_LOG_PIN_OUT,strPinNames[pin_no][0] + " => " + IntToStr( (int)val ) );
}

void PicSimulator::SetPinDataX(int pin_no, int val)
{
	int port_no, pin, i_val;

	if ( pin_no == iVccPin || pin_no == iResetPin ) return;
	
    if ( ( cPinStatus [ pin_no ] & 0x01 ) != 1 ) return;

    cPinData[pin_no] = val;
    portDriver.PinInputChanged(pin_no, val);
	
	// updating the RAi, .. signals
    portDriver.GetPinNo(pin_no, port_no, pin);
 	if (val) i_val = 1; else i_val = 0;
	((pic*)listener)->OnChangePinData(port_no, pin, i_val);
}

void PicSimulator::SetMemValue(int mem_addr,BYTE val,bool b_external_write)
{
     if ( mem_addr < 0 || mem_addr >= PIC_DEVICE_MEMORY_SIZE )return;

     /*if ( iInstructionLengthInBit == 12 )
     {
          SetMemValue33InstructionSet(mem_addr,val,b_external_write);
          return;
     }*/
     if ( ( mem_addr & 0x7F ) == 0 )
     {
          mem_addr = cMemory [ iFsrAddress ];
          if ( cMemory [ iStatusAddress ] & 0x80 )mem_addr += 0x100;
     }
     else if ( mem_addr == iPclAddress ) iCurrentPC = cMemory[iPclathAddress] * 256 + val; // -1 was added on 2 March 09 because, after calling this function, iCurrentPC++ will be executed, Attila: -1 removed, tested with MPLab
     else if ( !b_external_write && iBsrAddress != -1 && mem_addr != iBsrAddress && (mem_addr < iCommonRAMStart || mem_addr > iCommonRAMEnd) ) mem_addr += ( cMemory [ iBsrAddress ] & 0x1F ) * 128;

     mem_addr = iMemoryTransform[mem_addr];
     //if ( !bValidMemory[mem_addr] )listener->OnError(ERROR_WRITE_TO_BAD_LOCATION);

     BYTE prev_val = cMemory[mem_addr];
     NotifyMemoryChangeToPeripherals(mem_addr,val);

     if ( !bValidSfr[mem_addr] )
          ((pic*)listener)->OnWriteSram(mem_addr,cMemory[mem_addr]);
     else ((pic*)listener)->OnWriteSfr(mem_addr,cMemory[mem_addr], prev_val);
}

