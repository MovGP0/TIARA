#ifndef monitorH
#define monitorH

#include "systemc.h"
#include "C_SCPLI.h"

SC_MODULE(monitor)
{
  sc_in<sc_logic> QA,QB,QC,QD;

  SC_CTOR(monitor)
  {
    SC_METHOD(proc);
    sensitive << QA << QB << QC << QD;
  }

  void proc()
  {
    sc_pli_set_node_changed(true);
    sc_pause();
  }
};
#endif

