#ifndef topH
#define topH

#include "counter.h"

SC_MODULE(top)
{
  sc_signal<sc_logic> CLK,CLEAR,QA,QB,QC,QD;
  
  counter U1;

  SC_CTOR(top): U1("U1")
  {
    U1.CLK(CLK); U1.CLEAR(CLEAR); U1.QA(QA); U1.QB(QB); U1.QC(QC); U1.QD(QD); 
  }
};
#endif

