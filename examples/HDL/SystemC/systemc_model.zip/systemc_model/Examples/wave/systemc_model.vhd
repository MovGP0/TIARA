-- This is the interface part of the SystemC model 
-- The SystemC project compiled externally by Visual Studio 2015
-- The compiled DLL file and the interface file (VHDL) assigned by Tools/New Macro Wizard..
-- See the documentation for details

library ieee;
use ieee.std_logic_1164.all;

entity sine_saw_wave is
  port ( Clk : in std_logic;
       	 Reset : in std_logic;
         Enable : in std_logic;
         Sel0, Sel1 : in std_logic; -- 0: sine, 1: saw, 2: square wave
         D0 : out std_logic;
         D1 : out std_logic;
         D2 : out std_logic;
         D3 : out std_logic;
         D4 : out std_logic
         );
end sine_saw_wave;

architecture sine_saw_wave_a of sine_saw_wave is
begin
end sine_saw_wave_a;
