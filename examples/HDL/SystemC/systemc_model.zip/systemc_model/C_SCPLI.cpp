// Guide
// Check 
//   * explicit_add_ports
//   * PORT_DEBUG, SAFE_LOG
//   * top_prefix
//   * pli_flags (SC_PLI_MODEL)

#include "stdafx.h"
#include "sc_pli_externs.h"
#include "sc_pli_classes.h"
#include "C_SCPLI.h"
#include "systemc.h"
#include "string_util.h"
#include "util.h"

//#define MODEL_DEBUG
//#define PORT_DEBUG
//#define SAFE_LOG


using namespace std;

#define SC_PLI_NEWCOLLECT 0x0001
#define SC_PLI_MODEL      0x0002

#define N_VISIT_DBG_MAX 128

const int ver = 1;
const int explicit_add_ports = 0;

bool node_changed;
int analysis_mode, visit_c=0;
char tmp_buf[N_VISIT_DBG_MAX][128];
char value_buffer[128];

int pli_flags = SC_PLI_NEWCOLLECT /*| SC_PLI_MODEL*/;

const char* sc_type_id_str[] =
{
 "'unknown'",
 "'integer'",
 "'bit'",
 "'logic'",
 "'logic vector'",
 "'double'",
 "'bool'"
};

pli_interface_class** interface_ports;
pli_mixed_node* FMixedNodes;
int interface_port_count, interface_ports_added=0, FMacroPortsCount, FGraphNumbers, FMaxDigNodeCount, FMixedNodeCount, iChangedPinCount, iChangedPinIndex[N_MAX_PIN], bChangedPinLevel[N_MAX_PIN], iDDRChangeCount, c_level;
pli_dig_node_to_signal* dig_node_to_signal;
char buffer[512]  = "";
char log_file_name[512] = "c:\\temp\\systemc_log.txt";
char debug_file_name[512] = "c:\\temp\\systemc_debug.txt";
char hex_file_name[1024] = "";
FILE* F;
char** FMacroPorts=NULL;
char error_msg[1024];
double mcu_freq;
t_ddr_change ddr_changes[256];

const unsigned int ram_begin = 0x20;
const unsigned int ram_end = 0x7F;
const unsigned int flash_size = 0x2000;

unsigned int MCU_currentPC;

const wchar_t* PortDesignators[N_PORTS] = { L"RA",  L"RB" };

void sc_pli_connect()
{
}

void sc_pli_set_node_changed(bool a)
{
 node_changed = a;
}

bool sc_pli_get_node_changed()
{
 return node_changed;
}

int sc_pli_get_version()
{
 return ver;
}

void sc_pli_set_analysis_mode(int a)
{
 analysis_mode = a;
}

char* float2str(double f)
{
 sprintf(buffer, "%f", f);
 return buffer;
}

char* unit2str(sc_time_unit a)
{
 if (a == SC_FS) return "fs";
 else if (a == SC_PS) return "ps";
 else if (a == SC_NS) return "ns";
 else if (a == SC_US) return "us";
 else if (a == SC_MS) return "ms";
 else if (a == SC_SEC) return "s";
}

void debug_msg(string& s)
{
 F = fopen(log_file_name, "at");
 fprintf(F, "%s\n", s.c_str());
 #ifdef SAFE_LOG
 fclose(F);
 #endif
}

void debug_string(char* s)
{
 F = fopen(log_file_name, "at");
 fprintf(F, "%s\n", s);
 fclose(F);
}

#ifdef MODEL_DEBUG
 #define DEBUG_MSG(x) debug_msg(x);
#else
 #define DEBUG_MSG(x)
#endif

int sc_pli_newdesign( int argc, char* argv[] ) 
{
 iDDRChangeCount = 0;
 memset(tmp_buf, 0, sizeof(tmp_buf));
 return main( argc, argv );
}

void sc_pli_run(double duration, int unit)
{
 string s = string("sc_pli_run: duration: ")+string(float2str(duration))+string(unit2str((sc_time_unit)unit)); DEBUG_MSG(s) 
 sc_start(duration, (sc_time_unit)unit);
}

char* get_macro_port_name(int a)
{
 if (a < FMacroPortsCount) return FMacroPorts[a]; else throw exception("get_macro_port_name");
}

pli_mixed_node* find_mixed_node(char* name)
{
 pli_mixed_node* o;

 o = FMixedNodes;
 for (int i=0; i<FMixedNodeCount; i++) {
  if (!_stricmp(o->name, name)) return o;
  o++;
 }
 return NULL;
}

const char* sc_type_id2str(int type_id)
{
 return sc_type_id_str[type_id];
}

void show_pin_error(int type_id, char* pin_name)
{
 const char* type_name;

 if (type_id >= 0 && type_id <= TYPE_MAX) type_name = sc_type_id2str(type_id); else type_name = "<undeifned>";
 strcpy(error_msg, "In the SystemC model the expected type at pin '");
 strcat(error_msg, pin_name); strcat(error_msg, "' is ");
 strcat(error_msg, type_name);
 throw exception(error_msg);
}

void show_pin_error_invalid(char* pin_name)
{
 strcpy(error_msg, "In the SystemC model the pin type is invalid at pin '");
 strcat(error_msg, pin_name); strcat(error_msg, "'");
 throw exception(error_msg);
}

void show_error(char* msg)
{
 strcpy(error_msg, msg);
 throw exception(error_msg);
}

void sc_pli_collect_interface_ports()
{
  int c=0;

  if (!explicit_add_ports && (pli_flags & SC_PLI_NEWCOLLECT))
	  traverse_objects();
  
  interface_port_count = FMacroPortsCount; 
}

int sc_pli_get_interface_port_count()
{
 return interface_port_count;
}

double sc_pli_get_simulation_time()
{
 double t = sc_get_curr_simcontext()->time_stamp().to_seconds();
 return t;
}

double sc_pli_get_next_event_time()
{
 double t = sc_time_to_pending_activity().to_seconds();
 return t;
}

char* find_interface_node(char* name)
{
 pli_interface_class* o;

 for (int i=0; i<interface_port_count; i++) {
  o = interface_ports[i];
  if (!_stricmp(o->name, name)) return (char*)o;
 }
 return NULL;
}
 
void sc_pli_init_types(void* pMacroPorts, char* pMacroTypes, int nMacroPortsCount)
{
  for (int i=0; i<FMacroPortsCount; i++) {
   if (interface_ports[i]->type_id != BOOL_TO_STD_LOGIC_TYPE_ID_VIRTUAL)
    interface_ports[i]->type_id = pMacroTypes[i];  
  }
}
 
bool sc_pli_init_mixed_nodes(void* pMixedNodes, void* pMacroPorts, int nMixedNodeCount, int nMacroPortsCount, int nGraphNumbers, char*& msg)
{
 pli_mixed_node* p_node;
 pli_interface_class* i_node;
 int max_idx;

 try {
  string s = string("sc_pli_init_mixed_nodes"); DEBUG_MSG(s)  
  
  p_node = (pli_mixed_node*)pMixedNodes; max_idx = -1;
  for (int i=0; i<nMixedNodeCount; i++) {
   if (p_node->dig_node > max_idx) max_idx = p_node->dig_node;
   p_node++;
  }
  
  FMacroPorts = (char**)pMacroPorts; FGraphNumbers = nGraphNumbers; FMacroPortsCount = nMacroPortsCount; FMixedNodeCount = nMixedNodeCount; FMixedNodes = (pli_mixed_node*)pMixedNodes; msg = error_msg;
  FMaxDigNodeCount = max_idx+1;
  dig_node_to_signal = new pli_dig_node_to_signal[FMaxDigNodeCount];
  sc_pli_collect_interface_ports();

  p_node = (pli_mixed_node*)pMixedNodes;
  for (int i=0; i<nMixedNodeCount; i++) {
   i_node = (pli_interface_class*)find_interface_node(p_node->name);
   if (i_node) {
    string s = string("sc_pli_init_mixed_nodes: node found: name: ")+string(p_node->name); DEBUG_MSG(s)
    i_node->dig_node = p_node->dig_node;
    dig_node_to_signal[p_node->dig_node].i_node = i_node;
   }
   p_node++;
  }
  
  return true;
 }
 catch (exception E) {
  return false;
 }
}

void sc_pli_free()
{
 delete [] dig_node_to_signal;
}

void sc_pli_finally()
{
 #ifdef MODEL_DEBUG
 #ifndef SAFE_LOG
 fclose(F);
 #endif
 #endif
}

int sc_pli_get_digital_node_value(int dig_node, int& typ)
{
  sc_object * p=NULL;
  sc_in<sc_logic>* p_sc_logic_in=NULL; sc_out<sc_logic>* p_sc_logic_out=NULL; sc_inout<sc_logic>* p_sc_logic_inout=NULL;
  sc_in<sc_bit>* p_sc_bit_in=NULL; sc_out<sc_bit>* p_sc_bit_out=NULL; sc_inout<sc_bit>* p_sc_bit_inout=NULL;
  sc_in<bool>* p_bool_in=NULL; sc_out<bool>* p_bool_out=NULL; sc_inout<bool>* p_bool_inout=NULL;
  sc_in<double>* p_double_in=NULL; sc_out<double>* p_double_out=NULL; sc_inout<double>* p_double_inout=NULL;
  sc_in<int>* p_int_in=NULL; sc_out<int>* p_int_out=NULL; sc_inout<int>* p_int_inout=NULL;

 pli_interface_class* i_node;
 if (dig_node >= FMaxDigNodeCount) show_error("dig_node >= FMaxDigNodeCount");
 i_node = dig_node_to_signal[dig_node].i_node;
 typ = 0;
 
 if (i_node->type_id == STD_LOGIC_TYPE_ID_VIRTUAL) {
  typ = STD_LOGIC_TYPE_ID_VIRTUAL;
  
  // CHANGE1
  sc_signal<sc_logic>* pt; 
  if (i_node->type_cast == TYPE_CAST_SC_SIGNAL)
   pt = dynamic_cast<sc_signal<sc_logic>*>((sc_signal<sc_logic>*)i_node->p_object);
  else if (i_node->type_cast == TYPE_CAST_SC_IN) {
   p_sc_logic_in = dynamic_cast<sc_in<sc_logic>*>((sc_in<sc_logic>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<sc_logic>*>(p_sc_logic_in->get_interface());
  }
  else if (i_node->type_cast == TYPE_CAST_SC_OUT) {
   p_sc_logic_out = dynamic_cast<sc_out<sc_logic>*>((sc_out<sc_logic>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<sc_logic>*>(p_sc_logic_out->get_interface());
  }
  else if (i_node->type_cast == TYPE_CAST_SC_INOUT) {
   p_sc_logic_inout = dynamic_cast<sc_inout<sc_logic>*>((sc_inout<sc_logic>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<sc_logic>*>(p_sc_logic_inout->get_interface());
  }
  if (!pt) throw exception("sc_pli_ad_interface: pt == NULL");

  sc_logic a = pt->read();
  sc_dt::sc_logic_value_t tmp = a.value(); 
  int v = (int)tmp;
  return v;
 }
 
 else if (i_node->type_id == BIT_TYPE_ID_VIRTUAL) {
  typ = BIT_TYPE_ID_VIRTUAL;
  
  sc_signal<sc_bit>* pt; 
  if (i_node->type_cast == TYPE_CAST_SC_SIGNAL)
   pt = dynamic_cast<sc_signal<sc_bit>*>((sc_signal<sc_bit>*)i_node->p_object);
  else if (i_node->type_cast == TYPE_CAST_SC_IN) {
   p_sc_bit_in = dynamic_cast<sc_in<sc_bit>*>((sc_in<sc_bit>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<sc_bit>*>(p_sc_bit_in->get_interface());
  }
  else if (i_node->type_cast == TYPE_CAST_SC_OUT) {
   p_sc_bit_out = dynamic_cast<sc_out<sc_bit>*>((sc_out<sc_bit>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<sc_bit>*>(p_sc_bit_out->get_interface());
  }
  else if (i_node->type_cast == TYPE_CAST_SC_INOUT) {
   p_sc_bit_inout = dynamic_cast<sc_inout<sc_bit>*>((sc_inout<sc_bit>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<sc_bit>*>(p_sc_bit_inout->get_interface());
  }
  if (!pt) throw exception("sc_pli_ad_interface: pt == NULL");

  int v;
  sc_bit a = pt->read();
  bool b = a.to_bool();
  if (b) v = 1; else v = 0;
  return v;
 }
 
 else if (i_node->type_id == BOOLEAN_TYPE_ID_VIRTUAL) {
  typ = BOOLEAN_TYPE_ID_VIRTUAL;

  sc_signal<bool>* pt; 
  if (i_node->type_cast == TYPE_CAST_SC_SIGNAL)
   pt = dynamic_cast<sc_signal<bool>*>((sc_signal<bool>*)i_node->p_object);
  else if (i_node->type_cast == TYPE_CAST_SC_IN) {
   p_bool_in = dynamic_cast<sc_in<bool>*>((sc_in<bool>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<bool>*>(p_bool_in->get_interface());
  }
  else if (i_node->type_cast == TYPE_CAST_SC_OUT) {
   p_bool_out = dynamic_cast<sc_out<bool>*>((sc_out<bool>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<bool>*>(p_bool_out->get_interface());
  }
  else if (i_node->type_cast == TYPE_CAST_SC_INOUT) {
   p_bool_inout = dynamic_cast<sc_inout<bool>*>((sc_inout<bool>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<bool>*>(p_bool_inout->get_interface());
  }
  if (!pt) throw exception("sc_pli_ad_interface: pt == NULL");
  
  bool a = pt->read();
  int v;
  if (a) v = 1; else v = 0;
  return v;
 } 
 
 else if (i_node->type_id == BOOL_TO_STD_LOGIC_TYPE_ID_VIRTUAL) {
  typ = STD_LOGIC_TYPE_ID_VIRTUAL;
  
  sc_signal<bool>* pt; 
  if (i_node->type_cast == TYPE_CAST_SC_SIGNAL)
   pt = dynamic_cast<sc_signal<bool>*>((sc_signal<bool>*)i_node->p_object);
  else if (i_node->type_cast == TYPE_CAST_SC_IN) {
   p_bool_in = dynamic_cast<sc_in<bool>*>((sc_in<bool>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<bool>*>(p_bool_in->get_interface());
  }
  else if (i_node->type_cast == TYPE_CAST_SC_OUT) {
   p_bool_out = dynamic_cast<sc_out<bool>*>((sc_out<bool>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<bool>*>(p_bool_out->get_interface());
  }
  else if (i_node->type_cast == TYPE_CAST_SC_INOUT) {
   p_bool_inout = dynamic_cast<sc_inout<bool>*>((sc_inout<bool>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<bool>*>(p_bool_inout->get_interface());
  }
  if (!pt) throw exception("sc_pli_ad_interface: pt == NULL");

  bool a = pt->read();
  int v;
  if (a) 
	  v = (int)sc_dt::Log_1; 
  else 
	  v = (int)sc_dt::Log_0;
  return v;
 }
 
 return 0;
}

double sc_pli_get_digital_node_value_real(int dig_node)
{
 pli_interface_class* i_node;
 if (dig_node >= FMaxDigNodeCount) show_error("dig_node >= FMaxDigNodeCount");
 i_node = dig_node_to_signal[dig_node].i_node;
 
 if (i_node->type_id == FLOAT_TYPE_ID_VIRTUAL) {
  sc_signal<double>* pt = (sc_signal<double>*)i_node->p_object;

  double a = pt->read();
  return a;
 }
 
 return 0;
}

bool sc_logic2bool(sc_logic& a)
{
 if (a.value() == SC_LOGIC_1) return true; else return false;
}

int sc_logic2bit(sc_logic& a)
{
 if (a.value() == SC_LOGIC_1) return 1; else return 0;
}

bool is_mcu_mode()
{
 return hex_file_name[0] != '\0';
}

void sc_pli_ad_interface(int dig_node, int val)
{
  pli_interface_class* i_node;
  sc_object * p=NULL;
  sc_in<sc_logic>* p_sc_logic_in=NULL; sc_out<sc_logic>* p_sc_logic_out=NULL; sc_inout<sc_logic>* p_sc_logic_inout=NULL;
  sc_in<sc_bit>* p_sc_bit_in=NULL; sc_out<sc_bit>* p_sc_bit_out=NULL; sc_inout<sc_bit>* p_sc_bit_inout=NULL;
  sc_in<bool>* p_bool_in=NULL; sc_out<bool>* p_bool_out=NULL; sc_inout<bool>* p_bool_inout=NULL;
  sc_in<double>* p_double_in=NULL; sc_out<double>* p_double_out=NULL; sc_inout<double>* p_double_inout=NULL;
  sc_in<int>* p_int_in=NULL; sc_out<int>* p_int_out=NULL; sc_inout<int>* p_int_inout=NULL;
 
 
 if (dig_node >= FMaxDigNodeCount) show_error("dig_node >= FMaxDigNodeCount");
 i_node = dig_node_to_signal[dig_node].i_node;
 
 if (i_node->type_id == STD_LOGIC_TYPE_ID_VIRTUAL) {
  
  // CHANGE1
  sc_signal<sc_logic>* pt; 
  if (i_node->type_cast == TYPE_CAST_SC_SIGNAL)
   pt = (sc_signal<sc_logic>*)i_node->p_object;
  else if (i_node->type_cast == TYPE_CAST_SC_IN) {
   p_sc_logic_in = dynamic_cast<sc_in<sc_logic>*>((sc_in<sc_logic>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<sc_logic>*>(p_sc_logic_in->get_interface());
  }
  else if (i_node->type_cast == TYPE_CAST_SC_OUT) {
   p_sc_logic_out = dynamic_cast<sc_out<sc_logic>*>((sc_out<sc_logic>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<sc_logic>*>(p_sc_logic_out->get_interface());
  }
  else if (i_node->type_cast == TYPE_CAST_SC_INOUT) {
   p_sc_logic_inout = dynamic_cast<sc_inout<sc_logic>*>((sc_inout<sc_logic>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<sc_logic>*>(p_sc_logic_inout->get_interface());
  }
  if (!pt) throw exception("sc_pli_ad_interface: pt == NULL");

  sc_logic a(val);
  
  if (is_mcu_mode()) {
   iChangedPinIndex[iChangedPinCount] = i_node->pin_no; // pin_no sets in SetPinLayout
   bChangedPinLevel[iChangedPinCount++] = val;
   
   #ifdef DEBUG
   debug.open(debug_file_name, std::ofstream::out | std::ofstream::app);
   debug << "sc_pli_ad_interface: name: " << i_node->name << ", time: " << sc_simulation_time() << ", val: " << a << ", iChangedPinCount: " << iChangedPinCount << endl;
   debug.close();
   #endif
  } 
	  
  pt->write(a);
 }
 
 else if (i_node->type_id == BIT_TYPE_ID_VIRTUAL) {
  
  sc_signal<sc_bit>* pt; 
  if (i_node->type_cast == TYPE_CAST_SC_SIGNAL)
   pt = dynamic_cast<sc_signal<sc_bit>*>((sc_signal<sc_bit>*)i_node->p_object);
  else if (i_node->type_cast == TYPE_CAST_SC_IN) {
   p_sc_bit_in = dynamic_cast<sc_in<sc_bit>*>((sc_in<sc_bit>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<sc_bit>*>(p_sc_bit_in->get_interface());
  }
  else if (i_node->type_cast == TYPE_CAST_SC_OUT) {
   p_sc_bit_out = dynamic_cast<sc_out<sc_bit>*>((sc_out<sc_bit>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<sc_bit>*>(p_sc_bit_out->get_interface());
  }
  else if (i_node->type_cast == TYPE_CAST_SC_INOUT) {
   p_sc_bit_inout = dynamic_cast<sc_inout<sc_bit>*>((sc_inout<sc_bit>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<sc_bit>*>(p_sc_bit_inout->get_interface());
  }
  if (!pt) throw exception("sc_pli_ad_interface: pt == NULL");

  sc_logic b(val);
  val = sc_logic2bit(b);
  sc_bit a(val);
  pt->write(a);
 }

 else if (i_node->type_id == BOOLEAN_TYPE_ID_VIRTUAL || i_node->type_id == BOOL_TO_STD_LOGIC_TYPE_ID_VIRTUAL) {
	 
  sc_signal<bool>* pt; 
  if (i_node->type_cast == TYPE_CAST_SC_SIGNAL)
   pt = dynamic_cast<sc_signal<bool>*>((sc_signal<bool>*)i_node->p_object);
  else if (i_node->type_cast == TYPE_CAST_SC_IN) {
   p_bool_in = dynamic_cast<sc_in<bool>*>((sc_in<bool>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<bool>*>(p_bool_in->get_interface());
  }
  else if (i_node->type_cast == TYPE_CAST_SC_OUT) {
   p_bool_out = dynamic_cast<sc_out<bool>*>((sc_out<bool>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<bool>*>(p_bool_out->get_interface());
  }
  else if (i_node->type_cast == TYPE_CAST_SC_INOUT) {
   p_bool_inout = dynamic_cast<sc_inout<bool>*>((sc_inout<bool>*)i_node->p_object);
   pt = dynamic_cast<sc_signal<bool>*>(p_bool_inout->get_interface());
  }
  if (!pt) throw exception("sc_pli_ad_interface: pt == NULL");

  sc_logic a(val);
  bool b = sc_logic2bool(a);
  pt->write(b);
 }

}

void sc_pli_ad_interface_real(int dig_node, double val)
{
 pli_interface_class* i_node;
 if (dig_node >= FMaxDigNodeCount) show_error("dig_node >= FMaxDigNodeCount");
 i_node = dig_node_to_signal[dig_node].i_node;
 
 if (i_node->type_id == FLOAT_TYPE_ID_VIRTUAL) {
  sc_signal<double>* pt = (sc_signal<double>*)i_node->p_object;

  pt->write(val);
 }
}

void sc_pli_mcu_set_data(char* fn, double freq)
{
 strcpy(hex_file_name, fn);
 mcu_freq = freq;
 
 // init some variables
 iChangedPinCount = 0;
}

void sc_pli_mcu_clear_changes()
{
 iChangedPinCount = 0;
}

void sc_pli_mcu_clear_ddr_changes()
{
 iDDRChangeCount = 0;
}

int sc_pli_mcu_get_ddr_change_count()
{
	return iDDRChangeCount;
}

void sc_pli_mcu_get_ddr_change_info(int i, wchar_t*& sPinMain, int& iPinIndex, int& direction)
{
	t_ddr_change* a = &ddr_changes[i];
	
	iPinIndex = a->idx;
	direction = a->dir;
	sPinMain = a->name;
}

bool sc_pli_mcu_is_portpin(wchar_t* pin_name, wchar_t*& sPort, int& iPortIndex)
{
 int l;
 
 sPort = NULL; iPortIndex = 0;	
 for (int i=0; i<N_PORTS; i++)
	 if (StrWPos(PortDesignators[i], pin_name) == 1) {
 		 l = wcslen(PortDesignators[i]);
		 iPortIndex = ToInt(pin_name, l);
		 sPort = (wchar_t*)PortDesignators[i];
		 return true;
	 }
 return false;
}

void sc_pli_mcu_get_info(unsigned int& ram_begin_, unsigned int& ram_end_, unsigned int& flash_size_)
{
 ram_begin_ = ram_begin;
 ram_end_ = ram_end;
 flash_size_ = flash_size;
}

void Dbg_SetCurrentPC(unsigned int a)
{
 MCU_currentPC = a;
}

void sc_pli_mcu_get_debugger_data(unsigned int& a)
{
 a = MCU_currentPC;
}

int sc_pli_get_flags(void)
{
 return pli_flags;
}

//
//
//
const char* top_prefix = "TOP.";

void debug_ports()
{
	for (int i=0; i<visit_c; i++) {
		debug_string(tmp_buf[i]);
	}
}

int count_char(const char* p, char a)
{
	int i=0, c=0;
	
	while (p[i]) if (p[i++] == a) c++;
	return c;
}

// M_CHECK_TYPE(p_, _in, _out, _inout, bool)
#define M_CHECK_TYPE(a, b, c, d, e) ((p = dynamic_cast<sc_signal<e>*>(obj)) || \
                                     (a##e##b = dynamic_cast<sc_in<e>*>(obj)) || \
						             (a##e##c = dynamic_cast<sc_out<e>*>(obj)) || \
						             (a##e##d = dynamic_cast<sc_inout<e>*>(obj)))					 

void update_interface_port(void* p, int t, int& c)						 
{
 interface_ports[c]->p_object = p;
 interface_ports[c]->type_cast = t;
}

void add_interface_port(sc_object* obj, bool f, int& c)
{
  sc_object * p=NULL;
  sc_in<sc_logic>* p_sc_logic_in=NULL; sc_out<sc_logic>* p_sc_logic_out=NULL; sc_inout<sc_logic>* p_sc_logic_inout=NULL;
  sc_in<sc_bit>* p_sc_bit_in=NULL; sc_out<sc_bit>* p_sc_bit_out=NULL; sc_inout<sc_bit>* p_sc_bit_inout=NULL;
  sc_in<bool>* p_bool_in=NULL; sc_out<bool>* p_bool_out=NULL; sc_inout<bool>* p_bool_inout=NULL;
  sc_in<double>* p_double_in=NULL; sc_out<double>* p_double_out=NULL; sc_inout<double>* p_double_inout=NULL;
  sc_in<int>* p_int_in=NULL; sc_out<int>* p_int_out=NULL; sc_inout<int>* p_int_inout=NULL;

  pli_mixed_node* p_node;
  pli_interface_class* i_node;
  int tmp;
  const char* name = obj->name();
  
  if (c >= FMacroPortsCount) return;
  
  // CHANGE1
  if (M_CHECK_TYPE(p_, _in, _out, _inout, sc_logic)) {
    if (p) {sc_signal<sc_logic> * pt = dynamic_cast<sc_signal<sc_logic>*>(p); interface_ports[c]->p_object = pt; interface_ports[c]->type_cast = TYPE_CAST_SC_SIGNAL; } 
    else if (p_sc_logic_in) update_interface_port(p_sc_logic_in, TYPE_CAST_SC_IN, c); 
    else if (p_sc_logic_out) update_interface_port(p_sc_logic_out, TYPE_CAST_SC_OUT, c);
    else if (p_sc_logic_inout) update_interface_port(p_sc_logic_inout, TYPE_CAST_SC_INOUT, c);

    interface_ports[c]->name = get_macro_port_name(c);
    if (f) {
     p_node = find_mixed_node(interface_ports[c]->name);
     if (p_node && p_node->type_id != STD_LOGIC_TYPE_ID_VIRTUAL) show_pin_error(p_node->type_id, interface_ports[c]->name);
    }
    c++;
  }

  else if (M_CHECK_TYPE(p_, _in, _out, _inout, sc_bit)) {
    if (p) {sc_signal<sc_bit> * pt = dynamic_cast<sc_signal<sc_bit>*>(p); interface_ports[c]->p_object = pt; interface_ports[c]->type_cast = TYPE_CAST_SC_SIGNAL; } 
    else if (p_sc_bit_in) update_interface_port(p_sc_bit_in, TYPE_CAST_SC_IN, c); 
    else if (p_sc_bit_out) update_interface_port(p_sc_bit_out, TYPE_CAST_SC_OUT, c);
    else if (p_sc_bit_inout) update_interface_port(p_sc_bit_inout, TYPE_CAST_SC_INOUT, c);
	
    interface_ports[c]->name = get_macro_port_name(c);
    if (f) {
     p_node = find_mixed_node(interface_ports[c]->name);
     if (p_node && p_node->type_id != BIT_TYPE_ID_VIRTUAL) show_pin_error(p_node->type_id, interface_ports[c]->name);
    }
    c++;
  }

  else if (M_CHECK_TYPE(p_, _in, _out, _inout, bool)) {
    if (p) {sc_signal<bool> * pt = dynamic_cast<sc_signal<bool>*>(p); interface_ports[c]->p_object = pt; interface_ports[c]->type_cast = TYPE_CAST_SC_SIGNAL; } 
    else if (p_bool_in) update_interface_port(p_bool_in, TYPE_CAST_SC_IN, c); 
    else if (p_bool_out) update_interface_port(p_bool_out, TYPE_CAST_SC_OUT, c);
    else if (p_bool_inout) update_interface_port(p_bool_inout, TYPE_CAST_SC_INOUT, c);

    interface_ports[c]->name = get_macro_port_name(c);
    interface_ports[c]->type_id = BOOL_TO_STD_LOGIC_TYPE_ID_VIRTUAL;
    if (f) {
     p_node = find_mixed_node(interface_ports[c]->name);
     //if (p_node && p_node->type_id != BOOLEAN_TYPE_ID_VIRTUAL) show_pin_error(p_node->type_id, interface_ports[c]->name);
    }
    c++;
  }

  else if (M_CHECK_TYPE(p_, _in, _out, _inout, double)) {
    if (p) {sc_signal<double> * pt = dynamic_cast<sc_signal<double>*>(p); interface_ports[c]->p_object = pt; interface_ports[c]->type_cast = TYPE_CAST_SC_SIGNAL; } 
    else if (p_double_in) update_interface_port(p_double_in, TYPE_CAST_SC_IN, c); 
    else if (p_double_out) update_interface_port(p_double_out, TYPE_CAST_SC_OUT, c);
    else if (p_double_inout) update_interface_port(p_double_inout, TYPE_CAST_SC_INOUT, c);
	
    interface_ports[c]->name = get_macro_port_name(c);
    if (f) {
     p_node = find_mixed_node(interface_ports[c]->name);
     if (p_node && p_node->type_id != FLOAT_TYPE_ID_VIRTUAL) show_pin_error(p_node->type_id, interface_ports[c]->name);
    }
    c++;
  }

  else if (M_CHECK_TYPE(p_, _in, _out, _inout, int)) {
    if (p) {sc_signal<int> * pt = dynamic_cast<sc_signal<int>*>(p); interface_ports[c]->p_object = pt; interface_ports[c]->type_cast = TYPE_CAST_SC_SIGNAL; } 
    else if (p_int_in) update_interface_port(p_int_in, TYPE_CAST_SC_IN, c); 
    else if (p_int_out) update_interface_port(p_int_out, TYPE_CAST_SC_OUT, c);
    else if (p_int_inout) update_interface_port(p_int_inout, TYPE_CAST_SC_INOUT, c);
	
    interface_ports[c]->name = get_macro_port_name(c);
    if (f) {
     p_node = find_mixed_node(interface_ports[c]->name);
     if (p_node && p_node->type_id != INTEGER_TYPE_ID_VIRTUAL) show_pin_error(p_node->type_id, interface_ports[c]->name);
     if (analysis_mode != SC_MIXED_MODE) show_error("Integer type pins at interface ports not allowed in mixed mode");
    }
    c++;
  }
}

void visit( sc_object* obj, int& c )
{
  sc_object * p;
  pli_mixed_node* p_node;
  pli_interface_class* i_node;
  bool f=true;
  int tmp;
  const char* name = obj->name();
  
  if (visit_c < N_VISIT_DBG_MAX) strcpy(tmp_buf[visit_c++], name);

  tmp = count_char(name, '.');

  if (tmp != c_level || c >= FMacroPortsCount) return;
  
  add_interface_port( obj, true, c );
  
}

void traverse(sc_object* obj, int& c)
{
 std::vector<sc_object*> children = obj->get_child_objects();
 unsigned n = children.size();
 const char* name = obj->name();

 if (!n) {
  visit(obj, c);
  return;
 }
 
 for ( unsigned i = 0; i < n; i++ )
  traverse(children[i], c);
}

void init_interface_ports(int a, char** ports)
{
  FMacroPortsCount = a;
  
  interface_ports = (pli_interface_class**)calloc(FMacroPortsCount, sizeof(pli_interface_class));
  for ( unsigned i = 0; i < FMacroPortsCount; i++ )
   interface_ports[i] = new pli_interface_class;
  
  interface_ports_added = a;
  interface_port_count = a; 
  
  FMacroPorts = (char**)calloc(FMacroPortsCount, sizeof(char*));
  for ( unsigned i = 0; i < FMacroPortsCount; i++ ) {
   FMacroPorts[i] = (char*)calloc(strlen(ports[i]+1), 1);
   strcpy(FMacroPorts[i], ports[i]);
  }    
}

void traverse_objects()
{
  int c=0;	
  c_level = count_char(top_prefix, '.');
  
  const sc_simcontext* simc_p = sc_get_curr_simcontext();
  std::vector<sc_object*> tops = sc_get_top_level_objects();
  
  interface_ports = (pli_interface_class**)calloc(FMacroPortsCount, sizeof(pli_interface_class));
  for ( unsigned i = 0; i < FMacroPortsCount; i++ )
   interface_ports[i] = new pli_interface_class;
  
  unsigned n = tops.size();
  for ( unsigned i = 0; i < n; i++ )
   traverse(tops[i], c);  

  interface_ports_added = c;
  
  #ifdef PORT_DEBUG
  debug_ports();
  #endif
}

void* sc_pli_get_node_value(int idx)
{
 pli_interface_class* i_node;
 i_node = interface_ports[idx];
 int typ = 0;
 
 if (i_node->type_id == STD_LOGIC_TYPE_ID_VIRTUAL) {
  typ = STD_LOGIC_TYPE_ID_VIRTUAL;
  sc_signal<sc_logic>* pt = (sc_signal<sc_logic>*)i_node->p_object;

  sc_logic a = pt->read();
  sc_dt::sc_logic_value_t tmp = a.value(); 
  int v = (int)tmp;
  memcpy(value_buffer, &v, sizeof(v));
  return value_buffer;
 }
 
 else if (i_node->type_id == BIT_TYPE_ID_VIRTUAL) {
  typ = BIT_TYPE_ID_VIRTUAL;
  sc_signal<sc_bit>* pt = (sc_signal<sc_bit>*)i_node->p_object;

  int v;
  sc_bit a = pt->read();
  bool b = a.to_bool();
  if (b) v = 1; else v = 0;
  memcpy(value_buffer, &v, sizeof(v));
  return value_buffer;
 }
 
 else if (i_node->type_id == BOOLEAN_TYPE_ID_VIRTUAL) {
  typ = BOOLEAN_TYPE_ID_VIRTUAL;
  sc_signal<bool>* pt = (sc_signal<bool>*)i_node->p_object;

  bool a = pt->read();
  int v;
  if (a) v = 1; else v = 0;
  memcpy(value_buffer, &v, sizeof(v));
  return value_buffer;
 } 
 
 else if (i_node->type_id == BOOL_TO_STD_LOGIC_TYPE_ID_VIRTUAL) {
  typ = STD_LOGIC_TYPE_ID_VIRTUAL;
  sc_signal<bool>* pt = (sc_signal<bool>*)i_node->p_object;

  bool a = pt->read();
  int v;
  if (a) 
	  v = (int)sc_dt::Log_1; 
  else 
	  v = (int)sc_dt::Log_0;
  memcpy(value_buffer, &v, sizeof(v));
  return value_buffer;
 }
 
 else if (i_node->type_id == FLOAT_TYPE_ID_VIRTUAL) {
  sc_signal<double>* pt = (sc_signal<double>*)i_node->p_object;

  double v = pt->read();
  memcpy(value_buffer, &v, sizeof(v));
  return value_buffer;
 }
 
 return NULL;
}

