#include <stdint.h>
#include "inc/tm4c123gh6pm.h"
 
// PortF Pin3
#define GPIO_PORTF_DATA_WR      (*((volatile long *)0x40025020))

// Smaller delay when running the simulation
#define SIM

#ifdef SIM
 #define DELAY 2000
#else
 #define DELAY 200000
#endif

void GPIO_Init(void){
  SYSCTL_RCGCGPIO_R |= 0x20;        // 1) activate port F
  while((SYSCTL_PRGPIO_R&0x20)==0){};   // allow time for clock to stabilize
                                    // 2) no need to unlock PF3-0
  GPIO_PORTF_AMSEL_R &= ~0xFF;      // 3) disable analog functionality on PDF-0
  GPIO_PORTF_PCTL_R &= ~0x0000FFFF; // 4) GPIO
  GPIO_PORTF_DIR_R |= 0xFF;         // 5) make PF7-0 out
  GPIO_PORTF_AFSEL_R &= ~0xFF;      // 6) regular port function
  GPIO_PORTF_DEN_R |= 0xFF;         // 7) enable digital I/O on PF7-0
}

int main(void)
{
  GPIO_Init();
  
  while (1) {
   GPIO_PORTF_DATA_WR = 0; 
   for (int i=0; i<DELAY; i++) ;
  
   GPIO_PORTF_DATA_WR = 0xFF; 
   for (int i=0; i<DELAY; i++) ;
  }
  
  while(1) ;
}
