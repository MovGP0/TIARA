#ifndef monitorH
#define monitorH

#include "systemc.h"
#include "C_SCPLI.h"
#include "util.h"

#define MIXED_MODE

SC_MODULE(monitor)
{
  sc_in<sc_logic> RA0, RA1, RA2, RA3, RA4, RA5, RA6, RA7; 
  sc_in<sc_logic> RB0, RB1, RB2, RB3, RB4, RB5, RB6, RB7;
  sc_in<sc_logic> RC0, RC1, RC2, RC3, RC4, RC5, RC6, RC7;
 
  SC_CTOR(monitor)
  {
    SC_METHOD(proc);
    sensitive << RA0 << RA1 << RA2 << RA3 << RA4 << RA5 << RA6 << RA7 << RB0 << RB1 << RB2 << RB3 << RB4 << RB5 << RB6 << RB7 << RC0 << RC1 << RC2 << RC3 << RC4 << RC5 << RC6 << RC7;
  }

  void proc()
  {
	#ifdef DEBUG
    debug.open(debug_file_name, std::ofstream::out | std::ofstream::app);
    debug <<" At "<< sc_simulation_time() << " i/o is : ";
    debug << "(RA4-0): ";
    debug  << RA4.read() << RA3.read() << RA2.read() << RA1.read() << RA0.read() << endl;
    debug.close();
	#endif
	
	#ifdef MIXED_MODE
    sc_pli_set_node_changed(true);
    sc_pause();
	#endif
  }
};
#endif

