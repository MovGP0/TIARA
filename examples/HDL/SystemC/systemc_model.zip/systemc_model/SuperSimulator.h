#ifndef SuperSimulatorH
#define SuperSimulatorH 
 
#define MCU_SIMULATOR_TYPE_PIC          1  // MCU_SIMULATOR_TYPE_PIC18 = MCU_SIMULATOR_TYPE_PIC + 100
#define MCU_SIMULATOR_TYPE_AVR          2
#define MCU_SIMULATOR_TYPE_SERIES_51    3
#define MCU_SIMULATOR_TYPE_STANDALONE   4
#define MCU_SIMULATOR_TYPE_ARM          5
#define MCU_SIMULATOR_TYPE_PIC_24       6
#define MCU_SIMULATOR_TYPE_PIC_32       7

enum SimulatorResetType
{
        RESET_NONE = 0,
        RESET_EXTERNAL,
        RESET_POWER_ON,
        RESET_WATCHDOG,
		RESET_JTAG,
        RESET_BROWN_OUT,
        RESET_MCLR
};

class McuPeripheralUser
{
public:
        virtual void P_WriteMemory(int mem_addr,BYTE val) = 0;
        virtual BYTE P_ReadMemory(int mem_addr) = 0;
        virtual bool P_GetPinStatus(int pin_no) = 0;
        virtual void P_SetPinStatus(int pin_no,bool val) = 0;
        virtual void P_SetPinData(int pin_no,bool dt,bool from_port_driver = false ) = 0;
        virtual bool P_GetPinData(int pin_no) = 0;
        virtual void P_SetMemoryBit(int mem_addr,int bit_pos) = 0;
        virtual void P_ClearMemoryBit(int mem_addr,int bit_pos) = 0;

};

class McuSuperSimulator
{
 protected:
    enum
    {
         MAXIMUM_SFR_COUNT      = 4096,
         MAXIMUM_PIN_COUNT      = 1000,
         MAXIMUM_REGISTER_COUNT = 100
    };

    char *listener;

	// -------   FLASH SECTION ---------------------

	unsigned int                *iFlashCode;
	int                         *iFlashOpcodeID;
	int                         *iFlashOpcodeParam1;
	int                         *iFlashOpcodeParam2;
	int                         *iFlashOpcodeParam3;
	double                      *fPinVolt;          //this is initiated by inheritor
	int                         *iGndPins, *iVccPins;
	int                         iGndNum, iVccNum;

	int                         iFlashSize;
	int                         iEepromSize;

	__int64                     iLastNanoTime;
    int                         iCycleCountDown, DCO2_DIV;
    unsigned int                iFcDelayCount, iFcDelayCountData;

    int                         iSimulatorType;

	int                         iLogLevel, iInstructionExecuted;
	bool                        fLogState;
	unsigned int                max_addr;
	
	int                         iCurrentCycle, MCLK_DIV;

    int                         iCurrentInstructionNecessaryCycle, iCycleVal;

    double                      fSpeed; //in mega hertz
    bool                        bSleeping;

	int                         iVccPin;
	int                         iGndPin;
	int                         iResetPin;

	// -------   PIN SECTION -----------------------

	int                         iPinCount;
	int                         iPinAlternativeCount[MAXIMUM_PIN_COUNT];
	bool                        bSquareLayout;

	char                        strPinNames[MAXIMUM_PIN_COUNT][32][10];
	int                         iPinMapping[MAXIMUM_PIN_COUNT];

    void SetPinLayout(char* s_layout_, bool b_square_layout = false );
    int PinIndexFromName(char* s_name);

	virtual void       ExecuteCurrentInstructionOnly() = 0;

	char* PinNameFromIndex(int index)
    {
                       if ( index < 0 || index >= iPinCount )return "";
                       return strPinNames[index][0];
    }

 public:
	 McuSuperSimulator();
	
	__int64                     iNanoPerClock, iNanoPerClockWDT;
	
    int                         iLogType;
    bool                        fPCChanged, fPCChangedSim, fTimeChanged, fNodeChanged, fStartFinished;
    unsigned int                iCurrentPC;
	unsigned int                iInitPCVal;
	__int64                     fStopTime;
    int                         fStopMCUInstrCount, iMCUInstrExecuted, iMCUInstrSessionExecuted;
	
    virtual void       SetListener(char *parent){listener = parent;}
    bool StartSimulationEnv(double speed_mhz);
    virtual bool       StartSimulation() = 0;
    virtual int        GetSimulatorType() = 0;
    virtual void SetPinDataX(int pin_no, int val) = 0;
    void OnTimeChange();
};

extern const double CALC_MCU_PERIOD;
extern const __int64 FS, PS, NS, US, MS, Second, Minute, Hour, NS_MCU;

#endif
