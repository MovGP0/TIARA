#ifndef topH
#define topH

#include "clock.h"

SC_MODULE(top)
{
  sc_signal<sc_logic> CLK;
  
  clock U1;

  SC_CTOR(top): U1("U1")
  {
    U1.CLK(CLK);  
  }
};
#endif

