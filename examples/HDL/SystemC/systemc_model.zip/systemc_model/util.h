#ifndef utilH
#define utilH

#include <iostream>
#include <fstream>

extern std::ofstream debug;

#endif