#ifndef monitorH
#define monitorH

#include "systemc.h"
#include "C_SCPLI.h"

SC_MODULE(monitor)
{
  sc_in<sc_logic> S,C;

  SC_CTOR(monitor)
  {
    SC_METHOD(proc);
    sensitive << S << C;
  }

  void proc()
  {
    sc_pli_set_node_changed(true);
    sc_pause();
  }
};
#endif

