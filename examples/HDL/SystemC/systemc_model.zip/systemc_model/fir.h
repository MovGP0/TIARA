#ifndef firH
#define firH

#include "monitor.h"

#define M 99

extern const double b[M];

SC_MODULE(fir)
{
  sc_in<sc_logic> CLK;
  sc_in<double> SAMPLE;
  sc_out<double> RESULT;
  
  private:
   double x[M];
   int n;
 
  public:
   monitor MON;

   void proc();
  
   SC_CTOR(fir): MON("MON")
   {
	 // INIT  
	 n = 0;
     for(int i = 0; i < M; i++) x[i] = 0.0;
	 
     SC_METHOD(proc);
     sensitive << CLK;
     MON << RESULT;
   }
};
#endif

