#include "stdafx.h"
#include "C_SCDesign.h"
#include "C_SCPLI.h"


TSCDesign* design;

TSCDesign::TSCDesign()
{
}

TSCDesign::~TSCDesign()
{
}

void NewSystemCSession(char*& session_handle)
{
 TSCDesign* o;

 session_handle = NULL;

 o = new TSCDesign;
 design = o; //global!
 session_handle = (char*)o;
}

void FreeSystemCSession(char* session_handle)
{
 TSCDesign* o;

 o = (TSCDesign*)session_handle;
 delete o;
}

